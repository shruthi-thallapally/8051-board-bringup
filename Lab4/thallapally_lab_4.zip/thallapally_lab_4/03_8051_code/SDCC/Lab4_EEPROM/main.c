#include <stdint.h>
#include <stdio.h>
#include <mcs51/8051.h>
#include <mcs51/at89c51ed2.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <math.h>
#include "EEPROM.h"

// Function to initialize I2C communication
void init_i2c();

// Function to write a byte to EEPROM
void i2c_write();

// Function to read a byte from EEPROM
void i2c_read();

// Function to display a hexadecimal dump of EEPROM contents
void hex_dump();

// Function to reset the EEPROM
void eeprom_reset();

// Function to write data to I/O expander
void i2c_io_exp_write(__xdata uint16_t data);

// Function to read data from I/O expander
__xdata uint16_t i2c_io_exp_read();

// Function to get a hexadecimal number from user input
__xdata uint16_t get_num(int base);

// Function to print a hexadecimal number
void print_hex_num(__xdata uint16_t num, int width);

// Main function
void main(void)
{
    char in;
    __xdata uint16_t data_byte = 0;

    // Main loop
    do
    {
        printf_tiny("\n\r EEPROM MENU ");
        printf_tiny("\n\rPress 1 to Write Byte onto EEPROM");
        printf_tiny("\n\rPress 2 to Read Byte onto EEPROM");
        printf_tiny("\n\rPress 3 to display the Hex Dump");
        printf_tiny("\n\rPress 4 to Reset EEPROM");
        printf_tiny("\n\rPress 5 to I/O expander write");
        printf_tiny("\n\rPress 6 to I/O expander read\n\r");

        // Initialize I2C communication
        init_i2c();

        in = getchar();
        putchar(in);

        // Process user input
        if (in == '1')
        {
            printf_tiny("\n\rstart of EEPROM write\n\r");
            i2c_write();
        }
        else if (in == '2')
        {
            printf_tiny("\n\rstart of EEPROM read\n\r");
            i2c_read();
        }
        else if (in == '3')
        {
            printf_tiny("\n\rHex Dump\n\r");
            hex_dump();
        }
        else if (in == '4')
        {
            printf_tiny("\n\rReset EEPROM\n\r");
            eeprom_reset();
        }
        else if (in == '5')
        {
            printf_tiny("\n\rI/o expander write mode");
            printf_tiny("\n\rEnter Data : ");
            data_byte = get_num(16);
            i2c_io_exp_write(data_byte);
            printf_tiny("\n\rI/o expander Write complete\n\r");
        }
        else if (in == '6')
        {
            data_byte = i2c_io_exp_read();
            printf_tiny("\n\rI/o expander Read mode");
            printf_tiny("\n\rData read : ");
            print_hex_num(data_byte, 2);
        }
        else
        {
            printf_tiny("\n\rInvalid input. Please enter a valid input\n\r");
        }

    } while (1);
}
