
#include <stdint.h>
#include <stdio.h>
#include <mcs51/8051.h>
#include <mcs51/at89c51ed2.h>
#include <stdlib.h>
#include <math.h>
#include<string.h>
#include <math.h>




#define SCL P1_3 // Pin 6 of eeprom is connected to p1.3 of 8051
#define SDA P1_4 // Pin 5 of eeprom is connected to p1.4 of 8051


//Define i2c speed
#define I2C_SPEED_FACTOR  1 // for low i2c freq
#define Crystal_freq  12 //Mhz
#define HalfBitDelay (500*Crystal_freq)/(12*I2C_SPEED_FACTOR)

// Mask for the I/O expander bits in a byte
#define io_expander_mask (0x70)

// Mask for the most significant bit (MSB) in a byte
#define i2c_MSB_mask (0x80)

// Mask for the device address in write mode
#define device_address_mask (0xA0)

// Mask for the device address in read mode
#define device_address_mask_2 (0xAF)

// Mask for the read operation in I2C communication
#define read_mask (0x01)

// Mask for the write operation in I2C communication
#define write_mask (0xFE)

// Mask for the least significant bit (LSB) in a byte (high bit)
#define LSB_high_mask (0x01)

// Mask for the least significant bit (LSB) in a byte (low bit)
#define LSB_low_mask (0xFE)

// Size of the I2C EEPROM in bytes
#define i2c_eeprom_size (0x7FF)

//*****************************************************************************
//*				          Function Definitions								  *
//*****************************************************************************
// Function to output a character
int putchar(int ch);

// Function to input a character
int getchar(void);

// Function to introduce a delay
void delay(unsigned int a);

// I2C communication functions
void start_i2c(void);
void init_i2c(void);
void restart_i2c(void);
void stop_i2c(void);
void i2c_ack(void);
void i2c_NoAck(void);
int i2c_write_byte(uint8_t byte);
uint8_t i2c_read_byte(void);

// Functions for EEPROM read and write operations
uint16_t address_in(void);
uint16_t hex_read(uint16_t start_addr);
void i2c_write(void);
void i2c_read(void);


// Function to print a hex dump of EEPROM data
void hex_dump(void);

// Function to reset the EEPROM
void eeprom_reset(void);
uint8_t char_to_int(uint8_t temp);
int8_t int_to_char(int temp);

void i2c_clk_tick(void);
void ack_check();
uint8_t read_byte(void);
void write_byte(uint8_t data_byte);

/**
 * @brief Delays program execution for a specified duration.
 *
 * @param a The duration of the delay in arbitrary units.
 *            Note: The actual delay time may vary based on system characteristics.
 * @return void
 */
void delay(unsigned int a)
{
  unsigned int i, limit;

  // Calculate the loop limit based on the desired delay duration
  limit = a / 15;

  // Loop to create the delay
  for (i = 0; i < limit; i++)
  {
    ; // Empty statement, no operation
  }
}
/**
 * @brief Generates a single clock tick for I2C communication.
 *
 * This function sets the I2C clock (SCL) to high and then low, creating a single clock tick.
 *
 * @return void
 */
void i2c_clk_tick(void)
{
    // Set I2C clock (SCL) to high
    SCL = 1;

    // Set I2C clock (SCL) to low, completing the clock tick
    SCL = 0;

    // Return from the function
    return;
}

/**
 * @brief Waits for and checks the acknowledgment signal during I2C communication.
 *
 * This function generates a clock tick and then waits for the acknowledgment signal (SDA).
 * It remains in a loop until the acknowledgment signal is received (SDA becomes low).
 *
 * @return void
 */
void ack_check()
{
    // Generate a clock tick for I2C communication
    i2c_clk_tick();

    // Wait until the acknowledgment signal (SDA) becomes low
    while (SDA);

    // Return from the function
    return;
}
/**
 * @brief Waits for and retrieves a character from the serial port.
 *
 * This function waits until the Receiver Interrupt (RI) flag is set,
 * indicating that a character has been received. It then clears the RI flag,
 * retrieves the character from the Serial Buffer (SBUF), and returns it.
 *
 * @return The character received from the serial port.
 */
int getchar(void)
{
    // Wait until the Receiver Interrupt (RI) flag is set
    while (RI == 0)
    {
        ; // Empty statement, no operation
    }

    // Clear the Receiver Interrupt (RI) flag
    RI = 0;

    // Return the character received from the Serial Buffer (SBUF)
    return SBUF;
}

/**
 * @brief Sends a character to the serial port.
 *
 * This function waits until the Transmitter Interrupt (TI) flag is set,
 * indicating that the serial port is ready to transmit a character. It then
 * sends the specified character (x) to the Serial Buffer (SBUF), clears the
 * TI flag, and returns the transmitted character.
 *
 * @param x The character to be transmitted.
 * @return The transmitted character.
 */
int putchar(int x)
{
    // Wait until the Transmitter Interrupt (TI) flag is set
    while (TI == 0)
    {
        ; // Empty statement, no operation
    }

    // Send the specified character (x) to the Serial Buffer (SBUF)
    SBUF = x;

    // Clear the Transmitter Interrupt (TI) flag
    TI = 0;

    // Return the transmitted character
    return x;
}

/**
 * @brief Initiates the start condition for I2C communication.
 *
 * This function sets the I2C clock (SCL) and data (SDA) lines to the appropriate
 * levels to initiate the start condition. It includes a delay to achieve half the
 * bit duration and ensure proper signaling.
 *
 * @return void
 */
void start_i2c(void)
{
    // Set I2C clock (SCL) and data (SDA) lines to high
    SCL = 1;
    SDA = 1;

    // Introduce a delay to achieve half the bit duration
    delay(HalfBitDelay);

    // Set I2C data (SDA) line to low, initiating the start condition
    SDA = 0;

    // Introduce a delay to achieve half the bit duration
    delay(HalfBitDelay);
}

/**
 * @brief Initializes the I2C communication by setting the initial state of SDA and SCL lines.
 *
 * This function sets the I2C data (SDA) and clock (SCL) lines to an initial state,
 * preparing the I2C bus for communication.
 *
 * @return void
 */
void init_i2c()
{
    // Set I2C data (SDA) and clock (SCL) lines to high
    SDA = 1;
    SCL = 1;
}


/**
 * @brief Initiates a repeated start condition for I2C communication.
 *
 * This function generates a repeated start condition by toggling the I2C clock (SCL)
 * and data (SDA) lines to the appropriate levels, introducing delays to achieve half
 * the bit duration between transitions.
 *
 * @return void
 */
void restart_i2c()
{
    // Set I2C clock (SCL) to low
    SCL = 0;

    // Introduce a delay to achieve half the bit duration
    delay(HalfBitDelay / 2);

    // Set I2C data (SDA) line to high
    SDA = 1;

    // Introduce a delay to achieve half the bit duration
    delay(HalfBitDelay / 2);

    // Set I2C clock (SCL) to high
    SCL = 1;

    // Introduce a delay to achieve half the bit duration
    delay(HalfBitDelay / 2);

    // Set I2C data (SDA) line to low, initiating the repeated start condition
    SDA = 0;

    // Introduce a delay to achieve half the bit duration
    delay(HalfBitDelay / 2);
}

/**
 * @brief Initiates the stop condition for I2C communication.
 *
 * This function generates a stop condition by toggling the I2C clock (SCL) and
 * data (SDA) lines to the appropriate levels, introducing delays to achieve half
 * the bit duration between transitions.
 *
 * @return void
 */
void stop_i2c(void)
{
    // Set I2C clock (SCL) to low
    SCL = 0;

    // Introduce a delay to achieve half the bit duration
    delay(HalfBitDelay / 2);

    // Set I2C data (SDA) line to low
    SDA = 0;

    // Introduce a delay to achieve half the bit duration
    delay(HalfBitDelay / 2);

    // Set I2C clock (SCL) to high
    SCL = 1;

    // Introduce a delay to achieve half the bit duration
    delay(HalfBitDelay / 2);

    // Set I2C data (SDA) line to high, initiating the stop condition
    SDA = 1;

    // Introduce a delay to achieve half the bit duration
    delay(HalfBitDelay / 2);
}

/**
 * @brief Generates a No-Acknowledge condition during I2C communication.
 *
 * This function generates a No-Acknowledge condition by toggling the I2C clock (SCL)
 * and data (SDA) lines to the appropriate levels, introducing delays to achieve half
 * the bit duration between transitions.
 *
 * @return void
 */
void i2c_NoAck(void)
{
    // Set I2C clock (SCL) to low
    SCL = 0;

    // Introduce a delay to achieve half the bit duration
    delay(HalfBitDelay / 2);

    // Set I2C data (SDA) line to high, indicating No-Acknowledge
    SDA = 1;

    // Introduce a delay to achieve half the bit duration
    delay(HalfBitDelay / 2);

    // Set I2C clock (SCL) to high
    SCL = 1;

    // Introduce a delay to achieve half the bit duration
    delay(HalfBitDelay / 2);
}


/**
 * @brief Generates an Acknowledge condition during I2C communication.
 *
 * This function generates an Acknowledge condition by toggling the I2C clock (SCL)
 * and data (SDA) lines to the appropriate levels, introducing delays to achieve half
 * the bit duration between transitions.
 *
 * @return void
 */
void i2c_ack(void)
{
    // Set I2C clock (SCL) to low
    SCL = 0;

    // Introduce a delay to achieve half the bit duration
    delay(HalfBitDelay / 2);

    // Set I2C data (SDA) line to low, indicating Acknowledge
    SDA = 0;

    // Introduce a delay to achieve half the bit duration
    delay(HalfBitDelay / 2);

    // Set I2C clock (SCL) to high
    SCL = 1;

    // Introduce a delay to achieve half the bit duration
    delay(HalfBitDelay / 2);

    // Uncomment the following line if you want to keep SCL low after generating Acknowledge
    // SCL = 0;
}

/**
 * @brief Writes a byte to the I2C bus.
 *
 * This function sends each bit of a byte to the I2C bus sequentially,
 * starting from the most significant bit (MSB). It uses the I2C clock (SCL)
 * and data (SDA) lines to transmit the bits with appropriate delays.
 *
 * @param byte The byte to be written to the I2C bus.
 * @return The state of the Serial Data (SDA) line after the byte transmission.
 *         0 indicates acknowledgment, and 1 indicates no acknowledgment.
 */
int i2c_write_byte(uint8_t byte)
{
    unsigned char i;

    // Iterate over each bit of the byte
    for (i = 0; i < 8; i++)
    {
        // Set I2C clock (SCL) to low
        SCL = 0;

        // Introduce a delay to achieve half the bit duration
        delay(HalfBitDelay / 2);

        // Set I2C data (SDA) line based on the current bit
        if ((byte << i) & 0x80)
            SDA = 1;
        else
            SDA = 0;

        // Introduce a delay to achieve half the bit duration
        delay(HalfBitDelay / 2);

        // Set I2C clock (SCL) to high
        SCL = 1;

        // Introduce a delay to achieve half the bit duration
        delay(HalfBitDelay);
    }

    // Set I2C clock (SCL) to low
    SCL = 0;

    // Set I2C data (SDA) line to high, initiating the Acknowledge bit
    SDA = 1;

    // Introduce a delay
    delay(HalfBitDelay);

    // Set I2C clock (SCL) to high
    SCL = 1;

    // Introduce a delay
    delay(HalfBitDelay);

    // Return the state of the Serial Data (SDA) line after the byte transmission
    return SDA;
}


/**
 * @brief Reads a byte from the I2C bus.
 *
 * This function receives each bit of a byte from the I2C bus sequentially,
 * starting from the most significant bit (MSB). It uses the I2C clock (SCL)
 * and data (SDA) lines to receive the bits with appropriate delays.
 *
 * @return The byte read from the I2C bus.
 */
uint8_t i2c_read_byte(void)
{
    uint8_t i, d, rxdata = 0;

    // Iterate over each bit of the byte
    for (i = 0; i < 8; i++)
    {
        // Set I2C clock (SCL) to low
        SCL = 0;

        // Set I2C data (SDA) line to high for data reception
        SDA = 1;

        // Introduce a delay
        delay(HalfBitDelay);

        // Set I2C clock (SCL) to high
        SCL = 1;

        // Introduce a delay to achieve half the bit duration
        delay(HalfBitDelay / 2);

        // Read the data bit from the I2C data (SDA) line
        d = SDA;

        // Update the received data byte with the current bit
        rxdata = rxdata | (SDA << (7 - i));

        // Introduce a delay to achieve half the bit duration
        delay(HalfBitDelay / 2);
    }

    // Return the byte read from the I2C bus
    return rxdata;
}

/**
 * @brief Writes a byte of data to a specified address in an I2C EEPROM.
 *
 * This function prompts the user to enter an EEPROM address and data to be written.
 * It validates the user input and then sends the address, word address, and data to the
 * I2C EEPROM through the I2C bus. The EEPROM address is converted to the corresponding
 * slave address and word address for the EEPROM.
 *
 * @return void
 */
void i2c_write()
{
    uint8_t add_flag;
    uint8_t data_flag;

    char in_address[3];
    uint16_t in_address_int[3];
    uint16_t address;
    uint16_t data;
    char in_data[2];
    uint16_t in_data_int[2];

    uint8_t slave_add;
    uint8_t word_add;

    uint8_t i;
    address = 0;
    data = 0;

    do
    {
        add_flag = 0;
        printf_tiny("\n\rEnter the address between 0x00-0x7ff\n\r");

        // Get user input for EEPROM address
        for (i = 0; i < 3; i++)
        {
            in_address[i] = getchar();
            putchar(in_address[i]);
        }

        // Validate and convert user input to integer values
        for (i = 0; i < 3; i++)
        {
            switch (i)
            {
            case 0:
                if ((in_address[i] >= '0') && (in_address[i] <= '7'))
                {
                    in_address_int[i] = in_address[i] - 48;
                }
                else
                {
                    add_flag = 1;
                }
                break;

            case 1:
            case 2:
                if (((in_address[i] >= '0') && (in_address[i] <= '9')) || ((in_address[i] >= 'A') && (in_address[i] <= 'F')) || ((in_address[i] >= 'a') && (in_address[i] <= 'f')))
                {
                    if ((in_address[i] >= '0') && (in_address[i] <= '9'))
                    {
                        in_address_int[i] = in_address[i] - 48;
                    }
                    else if ((in_address[i] >= 'A') && (in_address[i] <= 'F'))
                    {
                        in_address_int[i] = in_address[i] - 55;
                    }
                    else if ((in_address[i] >= 'a') && (in_address[i] <= 'f'))
                    {
                        in_address_int[i] = in_address[i] - 87;
                    }
                }
                else
                {
                    add_flag = 1;
                }
                break;

            default:
                break;
            }
        }

        // Display error message for invalid input
        if (add_flag == 1)
        {
            printf_tiny("\n\rInvalid Input! Please enter again\n\r");
        }
    } while (add_flag == 1);

    // Convert the entered address to an integer value
    for (i = 0; i < 3; i++)
    {
        address = address + ((in_address_int[i]) * powf(16, 2 - i));
    }

    // Calculate the slave address for the EEPROM
    slave_add = ((0xA0) | (address >> 7) & (0xfe));

    // Get the word address for the EEPROM
    word_add = (uint8_t)address;

    do
    {
        data_flag = 0;
        printf_tiny("\n\rEnter the data you want to write (*Note: DATA SHOULD BE BETWEEN 0x00 and 0xFF)\n\r");

        // Get user input for data to be written
        for (i = 0; i < 2; i++)
        {
            in_data[i] = getchar();
            putchar(in_data[i]);
        }

        // Validate and convert user input to integer values
        for (i = 0; i < 2; i++)
        {
            switch (i)
            {
            case 0:
            case 1:
                if (((in_data[i] >= '0') && (in_data[i] <= '9')) || ((in_data[i] >= 'A') && (in_data[i] <= 'F')) || ((in_data[i] >= 'a') && (in_data[i] <= 'f')))
                {
                    if ((in_data[i] >= '0') && (in_data[i] <= '9'))
                    {
                        in_data_int[i] = in_data[i] - 48;
                    }
                    else if ((in_data[i] >= 'A') && (in_data[i] <= 'F'))
                    {
                        in_data_int[i] = in_data[i] - 55;
                    }
                    else if ((in_data[i] >= 'a') && (in_data[i] <= 'f'))
                    {
                        in_data_int[i] = in_data[i] - 87;
                    }
                }
                else
                {
                    data_flag = 1;
                }
                break;

            default:
                break;
            }
        }

        // Display error message for invalid input
        if (data_flag == 1)
        {
            printf("\n\rInvalid data input. Please enter a valid input\n\r");
        }

    } while (data_flag == 1);

    // Convert the entered data to an integer value
    for (i = 0; i < 2; i++)
    {
        data = data + ((in_data_int[i]) * powf(16, 1 - i));
    }

    // Start I2C communication and write data to EEPROM
    start_i2c();
    i2c_write_byte(slave_add);
    i2c_write_byte(word_add);
    i2c_write_byte(data);
    stop_i2c();
}

/**
 * @brief Reads a byte of data from a specified address in an I2C EEPROM.
 *
 * This function prompts the user to enter an EEPROM address, validates the user input,
 * and then sends the address and word address to the I2C EEPROM through the I2C bus.
 * It then initiates a read operation, receives the byte of data, and prints the received byte.
 * The EEPROM address is converted to the corresponding slave address and word address for the EEPROM.
 *
 * @return void
 */
void i2c_read()
{
    uint8_t add_flag;
    uint16_t address;
    uint16_t byte_received;
    char in_address[3];
    uint16_t in_address_int[3];
    uint8_t i;
    uint8_t slave_add;
    uint8_t word_add;
    uint8_t slave_read;
    address = 0;
    byte_received = 0x00;

    do
    {
        add_flag = 0;
        printf_tiny("\n\rEnter the address between 0x00-0x7ff\n\r");

        // Get user input for EEPROM address
        for (i = 0; i < 3; i++)
        {
            in_address[i] = getchar();
            putchar(in_address[i]);
        }

        // Validate and convert user input to integer values
        for (i = 0; i < 3; i++)
        {
            switch (i)
            {
            case 0:
                if ((in_address[i] >= '0') && (in_address[i] <= '7'))
                {
                    in_address_int[i] = in_address[i] - 48;
                }
                else
                {
                    add_flag = 1;
                }
                break;

            case 1:
            case 2:
                if (((in_address[i] >= '0') && (in_address[i] <= '9')) || ((in_address[i] >= 'A') && (in_address[i] <= 'F')) || ((in_address[i] >= 'a') && (in_address[i] <= 'f')))
                {
                    if ((in_address[i] >= '0') && (in_address[i] <= '9'))
                    {
                        in_address_int[i] = in_address[i] - 48;
                    }
                    else if ((in_address[i] >= 'A') && (in_address[i] <= 'F'))
                    {
                        in_address_int[i] = in_address[i] - 55;
                    }
                    else if ((in_address[i] >= 'a') && (in_address[i] <= 'f'))
                    {
                        in_address_int[i] = in_address[i] - 87;
                    }
                }
                else
                {
                    add_flag = 1;
                }
                break;

            default:
                break;
            }
        }

        // Display error message for invalid input
        if (add_flag == 1)
        {
            printf_tiny("\n\rInvalid Input! Please enter again\n\r");
        }
    } while (add_flag == 1);

    // Convert the entered address to an integer value
    for (i = 0; i < 3; i++)
    {
        address = address + ((in_address_int[i]) * powf(16, 2 - i));
    }

    // Calculate the slave address for the EEPROM
    slave_add = ((0xA0) | (address >> 7) & (0xfe));
    // Calculate the slave address for reading from the EEPROM
    slave_read = ((0xA0) | (address >> 7) | (0x01));
    // Get the word address for the EEPROM
    word_add = (uint8_t)address;

    // Start I2C communication and read data from EEPROM
    start_i2c();
    i2c_write_byte(slave_add);
    i2c_write_byte(word_add);
    restart_i2c();
    i2c_write_byte(slave_read);
    byte_received = i2c_read_byte();
    printf_tiny("\n\rByte received=%x\n\r", byte_received);
    i2c_NoAck();
    stop_i2c();
}


/**
 * @brief Reads a byte of data from a specified address in an I2C EEPROM.
 *
 * This function reads a byte of data from the specified EEPROM address
 * using the I2C communication protocol. It calculates the appropriate
 * slave address for writing and reading from the EEPROM and retrieves
 * the byte of data from the specified address.
 *
 * @param start_addr The starting address in the EEPROM to read from.
 * @return The byte of data read from the specified EEPROM address.
 */
uint16_t hex_read(uint16_t start_addr)
{
    uint16_t byte_received;
    uint8_t hex_add;
    uint16_t word_add;
    uint8_t hex_r;

    byte_received = 0;

    // Calculate the slave address for writing to the EEPROM
    hex_add = ((0xA0) | (start_addr >> 7) & (0xfe));
    // Calculate the slave address for reading from the EEPROM
    hex_r = ((0xA0) | (start_addr >> 7) | (0x01));
    // Get the word address for the EEPROM
    word_add = (uint8_t)start_addr;

    // Start I2C communication and read data from EEPROM
    start_i2c();
    i2c_write_byte(hex_add);
    i2c_write_byte(word_add);
    restart_i2c();
    i2c_write_byte(hex_r);

    // Receive the byte of data from the EEPROM
    byte_received = i2c_read_byte();

    // Send a No-Acknowledge signal to end the read operation
    i2c_NoAck();

    // Stop I2C communication
    stop_i2c();

    // Return the byte of data read from the specified EEPROM address
    return (byte_received);
}


/**
 * @brief Reads a hex address from the user and converts it to an integer value.
 *
 * This function prompts the user to enter a hex address, validates the user input,
 * and converts the hex address to an integer value for further use. It ensures that
 * the entered hex address is within the valid range.
 *
 * @return The integer value representing the entered hex address.
 */
uint16_t address_in()
{
    int add_flag;
    uint8_t i;
    uint16_t address_hex = 0;
    char hex_address[3];
    uint16_t hex_address_int[3];

    do
    {
        add_flag = 0;

        // Get user input for hex address
        for (i = 0; i < 3; i++)
        {
            hex_address[i] = getchar();
            putchar(hex_address[i]);
        }

        // Validate and convert user input to integer values
        for (i = 0; i < 3; i++)
        {
            switch (i)
            {
            case 0:
                if ((hex_address[i] >= '0') && (hex_address[i] <= '7'))
                {
                    hex_address_int[i] = hex_address[i] - 48;
                }
                else
                {
                    add_flag = 1;
                }
                break;

            case 1:
            case 2:
                if (((hex_address[i] >= '0') && (hex_address[i] <= '9')) || ((hex_address[i] >= 'A') && (hex_address[i] <= 'F')) || ((hex_address[i] >= 'a') && (hex_address[i] <= 'f')))
                {
                    if ((hex_address[i] >= '0') && (hex_address[i] <= '9'))
                    {
                        hex_address_int[i] = hex_address[i] - 48;
                    }
                    else if ((hex_address[i] >= 'A') && (hex_address[i] <= 'F'))
                    {
                        hex_address_int[i] = hex_address[i] - 55;
                    }
                    else if ((hex_address[i] >= 'a') && (hex_address[i] <= 'f'))
                    {
                        hex_address_int[i] = hex_address[i] - 87;
                    }
                }
                else
                {
                    add_flag = 1;
                }
                break;

            default:
                break;
            }
        }

        // Display error message for invalid input
        if (add_flag == 1)
        {
            printf_tiny("\n\rInvalid address. Please enter a valid address\n\r");
        }
    } while (add_flag == 1);

    // Convert the entered hex address to an integer value
    for (i = 0; i < 3; i++)
    {
        address_hex = address_hex + ((hex_address_int[i]) * powf(16, 2 - i));
    }

    // Return the integer value representing the entered hex address
    return (address_hex);
}

/**
 * @brief Performs a hex dump of data from a specified range of addresses in an I2C EEPROM.
 *
 * This function prompts the user to enter a start and stop address for the hex dump,
 * validates the user input, and performs the hex dump of data from the specified range
 * of addresses in the I2C EEPROM. It uses the `hex_read` function to read data from each
 * address and prints the data in a tabular format.
 *
 * @return void
 */
void hex_dump()
{
    uint16_t start_address;
    uint16_t stop_address;

    int address;
    int count = 0;
    int invalid_add = 0;
    uint16_t data;

    // Prompt the user to enter the start address for hex dump
    printf_tiny("\n\rEnter the START address between 0x00-0x7ff\n\r");
    start_address = address_in();

    // Prompt the user to enter the stop address for hex dump
    printf_tiny("\n\rEnter the STOP address between 0x00-0x7ff\n\r");
    stop_address = address_in();

    // Validate the entered addresses
    if (start_address <= stop_address)
    {
        printf_tiny("\n\rValid input\n\r");
    }
    else
    {
        invalid_add = 1;
        printf_tiny("\n\rInvalid Entries! Please enter addresses for hex dump again\n\r");
    }

    // Perform hex dump if addresses are valid
    if (invalid_add == 0)
    {
        for (address = start_address; address <= stop_address; address++)
        {
            if (address == start_address)
            {
                // Read and print data for the first address
                data = hex_read(start_address);
                printf_tiny("\n\r%x\t:%x", start_address, data);
            }
            else if (count != 15)
            {
                // Read and print data for subsequent addresses in the same line
                data = hex_read(address);
                printf_tiny("\t%x", data);
                count++;
            }
            else if (count == 15)
            {
                // Read and print data for the last address in the line
                data = hex_read(address);
                printf_tiny("\n\r%x\t:%x", address, data);
                count = 0;
            }
        }
    }

    printf_tiny("\n\rFinished printing hex_dump\n\r");
}


/**
 * @brief Resets an I2C EEPROM by sending a sequence of clock pulses and stop conditions.
 *
 * This function resets an I2C EEPROM by sending a sequence of clock pulses and stop conditions.
 * It generates a start condition, sends nine clock pulses with SDA high, followed by a stop condition.
 * The reset operation helps to bring the EEPROM back to a known state.
 *
 * @return void
 */
void eeprom_reset()
{
    uint8_t i;

    // Start I2C communication
    start_i2c();

    // Generate clock pulses with SDA high for EEPROM reset
    for (i = 0; i < 9; i++)
    {
        SDA = 1;
        SCL = 1;
        delay(HalfBitDelay);
        SCL = 0;
        delay(HalfBitDelay);
    }

    // Generate a stop condition
    SCL = 1;
    delay(HalfBitDelay);

    // Start I2C communication again (required after stop condition)
    start_i2c();

    // Stop I2C communication
    stop_i2c();
}

/**
 * @brief Writes a byte of data to an I/O expander device using I2C communication.
 *
 * This function writes a byte of data to an I/O expander device using I2C communication.
 * It first constructs the I2C address for the I/O expander by applying a mask and setting
 * the write bit. The function then checks the state of P7 in the data byte, inverts the
 * bits P0 to P6 if P7 is low, and proceeds to perform the I2C write operation.
 *
 * @param data_byte The byte of data to be written to the I/O expander.
 * @return void
 */
void i2c_io_exp_write(__xdata uint8_t data_byte)
{
    __xdata uint8_t addr = 0;

    // Set I/O expander address and write bit
    addr |= io_expander_mask;
    addr &= write_mask;

    // Check if P7 is low (bit 7 is low)
    if ((data_byte & (1 << 7)) == 0)
    {
        // Invert bits P0 to P6 using bitwise NOT (~)
        data_byte = ~data_byte; // 0x7F is binary 01111111
    }

    // Start I2C communication
    start_i2c();

    // Write I/O expander address
    write_byte(addr);
    ack_check();

    // Write data byte
    write_byte(data_byte);
    ack_check();

    // Stop I2C communication
    stop_i2c();

    return;
}



/**
 * @brief Reads a byte of data from an I/O expander device using I2C communication.
 *
 * This function reads a byte of data from an I/O expander device using I2C communication.
 * It first constructs the I2C address for the I/O expander by applying a mask and setting
 * the read bit. The function then performs the I2C read operation and sends an acknowledgment
 * signal after reading the data byte.
 *
 * @return The byte of data read from the I/O expander.
 */
__xdata uint8_t i2c_io_exp_read()
{
    __xdata uint8_t data_byte = 0, addr = 0;

    // Set I/O expander address and read bit
    addr |= io_expander_mask;
    addr |= read_mask;

    // Start I2C communication
    start_i2c();

    // Write I/O expander address for read
    write_byte(addr);
    ack_check();

    // Read data byte from I/O expander
    data_byte = read_byte();
    i2c_ack();

    // Stop I2C communication
    stop_i2c();

    return data_byte;
}



/**
 * @brief Reads and converts a number from the console input based on the specified base.
 *
 * This function reads characters from the console input until the Enter key is pressed,
 * allowing the user to input a number. It validates the entered characters based on the
 * specified base (e.g., decimal, hexadecimal) and converts them into an integer.
 * Backspace is supported for correcting input mistakes.
 *
 * @param base The numerical base of the input (e.g., 10 for decimal, 16 for hexadecimal).
 * @return The integer value obtained from the entered digits.
 */
uint16_t get_num(uint8_t base)
{
    __xdata uint8_t scanned_digit = 0, digit_array[20], digit_counter = 0, i = 0;
    __xdata uint16_t number = 0;

    // Loop until Enter key is pressed
    while (scanned_digit != 13)
    {
        scanned_digit = getchar();

        // Check if the scanned character is a valid digit or letter based on the specified base
        if (((scanned_digit >= '0') && (scanned_digit <= '9')) ||
            ((scanned_digit >= 'a') && (scanned_digit <= 'f')) ||
            ((scanned_digit >= 'A') && (scanned_digit <= 'F')))
        {
            // Print the scanned character to the console
            putchar(scanned_digit);

            // Convert the scanned character to an integer and store it in the array
            digit_array[digit_counter] = char_to_int(scanned_digit);
            digit_counter++;
        }
        else if (scanned_digit == 8) // Check for backspace
        {
            // Handle backspace by erasing the last entered character
            putchar(8);  // Print backspace
            putchar(32); // Print space
            putchar(8);  // Print backspace
            digit_counter--;
        }
    }

    // Convert the array of digits to an integer based on the specified base
    for (i = 0; i < digit_counter; i++)
    {
        number *= base;
        number += digit_array[i];
    }

    // Return the final integer value obtained from the entered digits
    return number;
}


/**
 * @brief Prints a hexadecimal number to the console with a specified display width.
 *
 * This function converts a given integer to a hexadecimal representation and prints it
 * to the console. It ensures a specified display width by adding leading zeros if needed.
 *
 * @param number The integer to be converted and printed in hexadecimal.
 * @param display_width The desired display width, indicating the minimum number of digits to display.
 */
void print_hex_num(__xdata uint32_t number, __xdata uint8_t display_width)
{
    // Array to store ASCII characters of the printed hexadecimal number
    __xdata uint8_t temp_ascii_store[10];

    // Temporary variables for loop control and value comparison
    __xdata int8_t counter = 0;
    __xdata uint32_t value_check = 0;

    // Loop to determine the number of digits required based on the display width
    for (counter = display_width; counter > 1; counter--)
    {
        // Check the display width and the value to determine if leading zero is needed
        switch (counter)
        {
        case 4:
            value_check = 0xFFF;
            if (number <= value_check)
            {
                putchar('0');
            }
            break;

        case 3:
            value_check = 0xFF;
            if (number <= value_check)
            {
                putchar('0');
            }
            break;

        case 2:
            value_check = 0xF;
            if (number <= value_check)
            {
                putchar('0');
            }
            break;
        }
    }

    // Loop to convert the integer to hexadecimal and store in the temporary array
    do
    {
        temp_ascii_store[counter] = int_to_char(number % 16);
        number /= 16;
        counter++;
    } while (number > 0);

    // Loop to print the ASCII characters to the console
    for (counter -= 1; counter >= 0; counter--)
    {
        putchar(temp_ascii_store[counter]);
    }

    // Return from the function
    return;
}



/**
 * @brief Converts a character representing a digit or hexadecimal letter to an integer.
 *
 * This function takes a character as input and checks whether it represents a digit ('0' to '9')
 * or a lowercase/uppercase hexadecimal letter ('a' to 'f' or 'A' to 'F'). It then converts
 * the character to its corresponding integer value.
 *
 * @param temp The character to be converted to an integer.
 * @return The integer value corresponding to the input character.
 */
uint8_t char_to_int(uint8_t temp)
{
    // Check if the character represents a digit
    if ((temp >= '0') && (temp <= '9'))
    {
        temp -= '0'; // Convert character to integer for digits
    }
    // Check if the character represents a lowercase hexadecimal letter
    else if ((temp >= 'a') && (temp <= 'f'))
    {
        temp -= 'a';
        temp += 10; // Convert character to integer for lowercase hexadecimal letters
    }
    // Check if the character represents an uppercase hexadecimal letter
    else if ((temp >= 'A') && (temp <= 'F'))
    {
        temp -= 'A';
        temp += 10; // Convert character to integer for uppercase hexadecimal letters
    }

    // Return the integer value corresponding to the input character
    return temp;
}



/**
 * @brief Converts an integer to its corresponding hexadecimal character representation.
 *
 * This function takes an integer as input and returns its corresponding hexadecimal
 * character representation. The function uses a switch-case statement to map each integer
 * in the range [0, 15] to its hexadecimal character representation ('0' to '9' and 'A' to 'F').
 * If the input integer is outside this range, it returns '0' as a default character.
 *
 * @param temp The integer to be converted to a hexadecimal character.
 * @return The hexadecimal character representation of the input integer.
 */
int8_t int_to_char(int temp)
{
    switch (temp)
    {
    case 0:
        return '0';

    case 1:
        return '1';

    case 2:
        return '2';

    case 3:
        return '3';

    case 4:
        return '4';

    case 5:
        return '5';

    case 6:
        return '6';

    case 7:
        return '7';

    case 8:
        return '8';

    case 9:
        return '9';

    case 10:
        return 'A';

    case 11:
        return 'B';

    case 12:
        return 'C';

    case 13:
        return 'D';

    case 14:
        return 'E';

    case 15:
        return 'F';

    default:
        // Handle cases where temp is not in the range [0, 15]
        return '0';
    }
}


/**
 * @brief Writes a byte of data to the I2C bus.
 *
 * This function sends a byte of data to the I2C bus, bit by bit. It uses the I2C clock ticks
 * to control the timing of each bit transmission. The function starts by pulling the clock line (SCL)
 * low and then iterates through the 8 bits of the data_byte, shifting each bit out while toggling
 * the data line (SDA) accordingly. After all bits are transmitted, the function leaves the data line low.
 *
 * @param data_byte The byte of data to be written to the I2C bus.
 */
void write_byte(uint8_t data_byte)
{
    uint8_t i = 0;

    // Pull the clock line low to start the byte transmission
    SCL = 0;

    // Iterate through each bit of the data_byte
    for (i = 0; i < 8; i++)
    {
        // Set or clear the data line (SDA) based on the current bit of data_byte
        if (data_byte & i2c_MSB_mask)
        {
            SDA = 1;
        }
        else
        {
            SDA = 0;
        }

        // Generate a clock tick to transmit the current bit
        i2c_clk_tick();

        // Shift to the next bit in data_byte
        data_byte = data_byte << 1;
    }

    // Leave the data line low after transmitting all bits
    SDA = 0;

    return;
}

/**
 * @brief Reads a byte of data from the I2C bus.
 *
 * This function reads a byte of data from the I2C bus, bit by bit. It assumes that the data line (SDA)
 * is initially set to 1. The function generates clock ticks to control the timing of each bit reception.
 * It starts by setting the data line to 1 and then iterates through the 8 bits, shifting the received
 * bits into the 'value' variable. The function leaves the data line high after reading all bits.
 *
 * @return The byte of data read from the I2C bus.
 */
uint8_t read_byte(void)
{
    uint8_t i = 0, value = 0;

    // Set the data line (SDA) to 1 before starting the byte reception
    SDA = 1;

    // Iterate through each bit of the byte to be read
    for (i = 0; i < 8; i++)
    {
        // Generate a clock tick to initiate bit reception
        SCL = 1;

        // Shift the current value to make space for the next bit
        value = value << 1;

        // Check the state of the data line (SDA) and update the current bit in 'value'
        if (SDA)
        {
            value |= LSB_high_mask;
        }
        else
        {
            value &= LSB_low_mask;
        }

        // Generate a clock tick to complete the bit reception
        SCL = 0;
    }

    // Return the byte of data read from the I2C bus
    return value;
}
