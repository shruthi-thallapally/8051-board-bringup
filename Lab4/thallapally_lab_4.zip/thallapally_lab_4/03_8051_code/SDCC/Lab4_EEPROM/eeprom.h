#ifndef __EEPROM_H
#define __EEPROM_H

/**
 * @file eeprom.h
 * @brief Header file for EEPROM functions and I2C communication.
 */

/**
 * @brief Writes data to the EEPROM using I2C communication.
 *
 * This function prompts the user to enter an address and data, then writes the data to the specified EEPROM address.
 */
void i2c_write();

/**
 * @brief Reads data from the EEPROM using I2C communication.
 *
 * This function prompts the user to enter an address and reads the data from the specified EEPROM address.
 */
void i2c_read();

/**
 * @brief Prints a hexadecimal dump of data stored in the EEPROM.
 *
 * This function prompts the user to enter start and stop addresses, then prints the hexadecimal representation
 * of the data stored in the specified EEPROM address range.
 */
void hex_dump();

/**
 * @brief Resets the EEPROM using I2C communication.
 *
 * This function resets the EEPROM by sending a sequence of signals through I2C communication.
 */
void eeprom_reset();

/**
 * @brief Initializes the I2C communication for EEPROM operations.
 *
 * This function initializes the I2C communication for EEPROM operations, setting necessary pins and parameters.
 */
void init_i2c();

/**
 * @brief Reads data from the I/O expander using I2C communication.
 *
 * @return The data read from the I/O expander.
 */
__xdata uint8_t i2c_io_exp_read();

/**
 * @brief Writes data to the I/O expander using I2C communication.
 *
 * @param data_byte The data byte to be written to the I/O expander.
 */
void i2c_io_exp_write(__xdata uint8_t data_byte);

/**
 * @brief Gets a numerical input from the user in the specified base.
 *
 * @param base The numerical base for the input (e.g., 10 for decimal, 16 for hexadecimal).
 * @return The numerical value entered by the user.
 */
uint16_t get_num(uint8_t base);

/**
 * @brief Prints a hexadecimal number to the console with a specified display width.
 *
 * @param number The hexadecimal number to be printed.
 * @param display_width The minimum width of the printed output.
 */
void print_hex_num(__xdata uint32_t number, __xdata uint8_t display_width);

/**
 * @brief Converts a character to its integer representation.
 *
 * @param temp The character to be converted.
 * @return The integer value corresponding to the input character.
 */
uint8_t char_to_int(uint8_t temp);

/**
 * @brief Converts an integer to its ASCII character representation.
 *
 * @param temp The integer to be converted.
 * @return The ASCII character corresponding to the input integer.
 */
int8_t int_to_char(int temp);

#endif // __EEPROM_H
