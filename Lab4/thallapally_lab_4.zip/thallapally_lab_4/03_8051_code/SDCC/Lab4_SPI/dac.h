#ifndef DAC_H_INCLUDED
#define DAC_H_INCLUDED

#include "at89c51ed2.h"
#include "mcs51reg.h"
#include <stdint.h>
#include "uart.h"

extern __xdata uint8_t wave, gain, mode;

/*
 * Function: dac_set
 * -----------------
 * Sets the output of the DAC with the specified 16-bit data word.
 * Parameters:
 *    - data_word: The 16-bit data word to be set as the DAC output.
 * Returns:
 *    - None
 */
void dac_set(uint16_t data_word);

/*
 * Function: dac_update_output
 * ---------------------------
 * Updates the DAC output based on the selected waveform, gain, and mode.
 * Parameters:
 *    - None
 * Returns:
 *    - None
 */
void dac_update_output(void);

/*
 * Function: spi_clk_tick
 * ----------------------
 * Simulates a clock tick for SPI communication.
 * Parameters:
 *    - None
 * Returns:
 *    - None
 */
void spi_clk_tick(void);

/*
 * Function: spi_init
 * ------------------
 * Initializes the SPI communication settings.
 * Parameters:
 *    - None
 * Returns:
 *    - None
 */
void spi_init(void);

/*
 * Function: spi_write_word
 * ------------------------
 * Writes a 16-bit word to the SPI DAC using a bit-banging approach.
 * Parameters:
 *    - data_word: The 16-bit word to be written to the SPI DAC.
 * Returns:
 *    - None
 */
void spi_write_word(__xdata uint16_t data_word);

/*
 * Function: dac_start_output
 * --------------------------
 * Starts the DAC output in normal operation mode.
 * Parameters:
 *    - None
 * Returns:
 *    - None
 */
void dac_start_output(void);

/*
 * Function: dac_stop_output
 * -------------------------
 * Stops the DAC output and disables the Timer 0.
 * Parameters:
 *    - None
 * Returns:
 *    - None
 */
void dac_stop_output(void);

/*
 * Function: dac_nxt_wave
 * -----------------------
 * Switches to the next waveform in the sequence.
 * Parameters:
 *    - None
 * Returns:
 *    - None
 */
void dac_nxt_wave(void);

/*
 * Function: dac_output_ctrl_change
 * --------------------------------
 * Changes the DAC output control mode between modes 0 and 1.
 * Parameters:
 *    - None
 * Returns:
 *    - None
 */
void dac_output_ctrl_change(void);

/*
 * Function: dac_inc_voltage
 * -------------------------
 * Increases the DAC output voltage by setting the gain to 2.
 * Parameters:
 *    - None
 * Returns:
 *    - None
 */
void dac_inc_voltage(void);

/*
 * Function: dac_dec_voltage
 * -------------------------
 * Decreases the DAC output voltage by setting the gain to 1.
 * Parameters:
 *    - None
 * Returns:
 *    - None
 */
void dac_dec_voltage(void);

#endif
