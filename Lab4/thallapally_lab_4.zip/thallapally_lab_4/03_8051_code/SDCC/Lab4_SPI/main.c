#include "at89c51ed2.h"
#include "mcs51reg.h"
#include <stdint.h>
#include <stdio.h>
#include "uart.h"
#include "dac.h"


/*
 * Function: _sdcc_external_startup
 * -------------------------------
 * External startup function to configure the hardware before the program starts.
 * Configures the auxiliary register (AUXR).
 * Returns: 0
 */
_sdcc_external_startup()
{
    AUXR |= 0x0C;  // Set the necessary bits in the AUXR register
    return 0;
}

/*
 * Function: wave_interrupt_handler
 * --------------------------------
 * Interrupt handler for the wave generation. Resets timer values and updates DAC output.
 * Parameters: None
 * Returns: None
 */
void wave_interrupt_handler(void) __interrupt 1
{
    TF0 = 0;  // Clear Timer 0 overflow flag
    TL0 = 0x00;  // Set low byte of Timer 0 to 0
    TH0 = 0xFC;  // Set high byte of Timer 0 for the next interrupt
    dac_update_output();  // Update DAC output
}

/*
 * Function: waves_init
 * --------------------
 * Initializes the wave generation by configuring timers and enabling interrupts.
 * Parameters: None
 * Returns: None
 */
void waves_init(void)
{
    IEN0 |= 0x82;  // Enable Timer 0 overflow interrupt and global interrupts
    TMOD |= 0x01;  // Set Timer 0 to mode 1 (16-bit timer)
    TMOD &= 0xF1;  // Clear unnecessary bits in Timer 0 mode
    TL0 = 0x00;  // Set low byte of Timer 0 to 0
    TH0 = 0xFC;  // Set high byte of Timer 0 for the next interrupt
    TR0 = 1;  // Start Timer 0
    return;
}

/*
 * Function: main
 * --------------
 * Main program function for ESD Lab 4 Supplemental. Handles user input and performs corresponding actions.
 * Parameters: None
 * Returns: None
 */
void main(void)
{
    __xdata uint8_t key_pressed = 0, data_byte = 0;
    __xdata uint16_t address = 0;

    // Display initial sentences
    printf_tiny("\n\rESD Lab 4 Supplemental");
    printf_tiny("\n\rPress '1' for Next wave,");
    printf_tiny("\n\rPress '2' to Increase DAC voltage,");
    printf_tiny("\n\rPress '3' to Decrease DAC voltage,");
    printf_tiny("\n\rPress '4' to Display Menu");

    // Initialize wave generation
    waves_init();

    while (1)
    {
        key_pressed = getchar();

        if (mode == 0)
        {
            TR0 = 0;  // Disable Timer 0 during menu display
        }

        switch (key_pressed)
        {
            case '4':
                {
                    printf_tiny("\n\rPress '1' for Next wave,");
                    printf_tiny("\n\rPress '2' to Increase DAC voltage,");
                    printf_tiny("\n\rPress '3' to Decrease DAC voltage,");
                    printf_tiny("\n\rPress '4' to Display Menu");
                    break;
                }

            case '9':
                {
                    dac_output_control_change();
                    printf_tiny("\n\rMode changed");
                    break;
                }

            case '1':
                {
                    printf_tiny("\n\rNext wave ");
                    dac_next_wave();
                    break;
                }

            case '0':
                {
                    printf_tiny("\n\rEnter Data ");
                    data_byte = fetch_number(16);
                    dac_set(data_byte);
                    break;
                }

            case '2':
                {
                    dac_increase_voltage();
                    printf_tiny("\n\rGain increased");
                    break;
                }

            case '3':
                {
                    dac_decrease_voltage();
                    printf_tiny("\n\rGain decreased");
                    break;
                }

            default:
                {
                    putchar(key_pressed);
                    break;
                }
        }

        if (mode == 0)
        {
            TR0 = 1;  // Re-enable Timer 0 after menu display
        }

        key_pressed = 0;
    }
}
