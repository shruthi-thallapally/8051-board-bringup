#ifndef UART_H_INCLUDED
#define UART_H_INCLUDED

#include <stdint.h>
#include "at89c51ed2.h"

extern __xdata uint8_t loop;

/*
 * Function: int_to_char
 * ---------------------
 * Converts an integer to its ASCII character representation.
 * Parameters: temp - Integer value to convert
 * Returns: ASCII character representation of the integer
 */
int8_t int_to_char(int temp);

/*
 * Function: print_number_hex
 * --------------------------
 * Prints a hexadecimal number to the UART with a specified display width.
 * Parameters: number - Number to be printed, display_width - Width of the display
 * Returns: None
 */
void print_number_hex(__xdata uint32_t number, __xdata uint8_t display_width);

/*
 * Function: getchar
 * -----------------
 * Waits for and returns a character received through UART.
 * Parameters: None
 * Returns: Character received through UART
 */
int getchar(void);

/*
 * Function: putchar
 * -----------------
 * Sends a character to UART for transmission.
 * Parameters: x - Character to be transmitted
 * Returns: Transmitted character
 */
int putchar(int x);

/*
 * Function: init_hardware
 * -----------------------
 * Initializes hardware settings for UART communication.
 * Parameters: None
 * Returns: None
 */
void init_hardware(void);

/*
 * Function: print_number
 * ----------------------
 * Prints an integer to the UART.
 * Parameters: number - Integer to be printed
 * Returns: None
 */
void print_number(__xdata int32_t number);

/*
 * Function: ms_delay
 * ------------------
 * Delays the program execution for a specified time in milliseconds.
 * Parameters: time - Time to delay in milliseconds
 * Returns: None
 */
void ms_delay(uint32_t time);

/*
 * Function: fetch_number
 * ----------------------
 * Reads a number from the user through UART, with a specified base.
 * Parameters: base - Number base for input
 * Returns: Read number
 */
uint16_t fetch_number(uint8_t base);

/*
 * Function: hex_dump
 * -------------------
 * Dumps hexadecimal values received through UART.
 * Parameters: None
 * Returns: None
 */
void hex_dump(void);

#endif
