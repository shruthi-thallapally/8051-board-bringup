#include "at89c51ed2.h"
#include "mcs51reg.h"
#include "uart.h"


/*
 * Function: init_hardware
 * -----------------------
 * Initializes the hardware settings for the microcontroller.
 * This function sets the clock control, enables interrupts, and configures Timer 1 and the UART.
 * Parameters:
 *    - None
 * Returns:
 *    - None
 */
void init_hardware(void) {
    CKCON0 = 0x01;    // Set clock control to system clock divided by 12
    IEN0 |= 0x80;     // Enable global interrupts (EA bit)
    IPL0 |= 0x10;     // Set priority level for serial port interrupts
    TMOD |= 0x20;     // Set Timer 1 to Mode 2 (8-bit auto-reload)
    SCON |= 0x50;     // Configure UART for 8-bit data, 1 stop bit, and enable receiver (REN)
    TCON |= 0x40;     // Start Timer 1
    TH1 = 0xFD;       // Set UART baud rate (adjust for specific baud rate)
    TI = 1;           // Set UART transmit flag to 1 (enable transmitter)
}

/*
 * Function: putchar
 * -----------------
 * Overrides the standard library function to send a character to the UART.
 * Waits until the UART transmit buffer is empty, then sends the character.
 * Parameters:
 *    - ch: The character to be sent.
 * Returns:
 *    - The sent character.
 */
int putchar(int ch) {
    while (TI == 0) {
        ;  // Wait for the UART transmit buffer to be empty
    }

    SBUF = ch;  // Send the character to the UART buffer
    TI = 0;     // Clear the UART transmit interrupt flag

    return ch;  // Return the sent character
}


/*
 * Function: getchar
 * -----------------
 * Overrides the standard library function to receive a character from the UART.
 * Waits until the UART receive buffer is full, then retrieves and returns the character.
 * Returns:
 *    - The received character from the UART.
 */
int getchar(void) {
    while (RI == 0) {
        ;  // Wait for the UART receive buffer to be full
    }

    RI = 0;        // Clear the UART receive interrupt flag
    return SBUF;   // Return the received character from the UART
}

/*
 * Function: char_to_int
 * ---------------------
 * Converts a character representing a digit or a hexadecimal letter to its integer equivalent.
 * Parameters:
 *    - temp: The character to be converted.
 * Returns:
 *    - The integer value corresponding to the input character.
 */
uint8_t char_to_int(uint8_t temp) {
    if ((temp >= '0') && (temp <= '9')) {
        temp -= '0';  // Convert character to integer for digits
    } else if ((temp >= 'a') && (temp <= 'f')) {
        temp -= 'a';
        temp += 10;   // Convert character to integer for lowercase hexadecimal letters
    } else if ((temp >= 'A') && (temp <= 'F')) {
        temp -= 'A';
        temp += 10;   // Convert character to integer for uppercase hexadecimal letters
    }
    return temp;
}

/*
 * Function: print_number
 * ----------------------
 * Prints an integer to the console.
 * Parameters:
 *    - number: The integer to be printed.
 * Returns:
 *    - None
 */
void print_number(__xdata int32_t number) {
    __xdata uint8_t temp_ascii_store[10];  // Array to store ASCII characters of the printed number
    __xdata int8_t counter = 0;  // Counter variable for loop control

    if (number < 0) {
        putchar('-');  // Print '-' for negative numbers
        number *= -1;  // Convert negative number to positive
    }

    // Loop to convert the integer to ASCII characters and store in the temporary array
    do {
        temp_ascii_store[counter] = '0' + number % 10;
        number /= 10;
        counter++;
    } while (number > 0);

    // Loop to print the ASCII characters to the console
    for (counter -= 1; counter >= 0; counter--) {
        putchar(temp_ascii_store[counter]);
    }
    return;
}


/*
 * Function: fetch_number
 * ----------------------
 * Reads user input from the console until the Enter key is pressed and converts the entered
 * digits to an integer based on the specified base (hexadecimal, decimal, etc.).
 * Parameters:
 *    - base: The numerical base for conversion (e.g., 10 for decimal, 16 for hexadecimal).
 * Returns:
 *    - The integer value obtained from the entered digits.
 */
uint16_t fetch_number(uint8_t base) {
    __xdata uint8_t scanned_digit = 0, digit_array[20], digit_counter = 0, i = 0;
    __xdata uint16_t number = 0;

    // Loop until Enter key is pressed
    while (scanned_digit != 13) {
        scanned_digit = getchar();

        // Check if the scanned character is a valid digit or letter based on the specified base
        if (((scanned_digit >= '0') && (scanned_digit <= '9')) ||
            ((scanned_digit >= 'a') && (scanned_digit <= 'f')) ||
            ((scanned_digit >= 'A') && (scanned_digit <= 'F'))) {
            putchar(scanned_digit);

            // Convert the scanned character to an integer and store it in the array
            digit_array[digit_counter] = char_to_int(scanned_digit);
            digit_counter++;
        } else if (scanned_digit == 8) {  // Check for backspace
            putchar(8);     // Print backspace
            putchar(32);    // Print space
            putchar(8);     // Print backspace
            digit_counter--;  // Decrement the counter for backspace
        }
    }

    // Convert the array of digits to an integer based on the specified base
    for (i = 0; i < digit_counter; i++) {
        number *= base;
        number += digit_array[i];
    }

    return number;
}


/*
 * Function: ms_delay
 * ------------------
 * Delays the program execution for a specified time in milliseconds.
 * Parameters:
 *    - time: The time duration for the delay in milliseconds.
 * Returns:
 *    - None
 */
void ms_delay(uint32_t time) {
    uint32_t i = 0, j = 0;

    // Loop for the specified number of milliseconds
    for (j = 0; j < time; j++) {
        // Inner loop to create a delay of approximately 1 millisecond
        for (i = 0; i < 1120; i++);
    }
    return;
}



