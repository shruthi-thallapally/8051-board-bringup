#include "dac.h"
// Mask to extract the Most Significant Bit (MSB) for SPI communication
#define SPI_MSB_MASK    (0x8000)

// Masks for A and B bits in control registers
#define A_MASK          (0x7FFF)
#define B_MASK          (0x8000)

// Mask to set GAIN_DEC bit in control register
#define GAIN_DEC_MASK   (0x2000)

// Mask to clear GAIN_INC bit in control register
#define GAIN_INC_MASK   (0xDFFF)

// Mask to set ACTIVE bit in control register
#define ACTIVE_MASK     (0x1000)

// Mask to clear SHUTDOWN bit in control register
#define SHUTDOWN_MASK   (0xEFFF)

// Number of samples for data processing
#define NO_OF_SAMPLES   (256)

// Total number of different waveform patterns
#define TOTAL_WAVES     (4)

// Pin definitions for DAC control lines
#define LDAC_BAR        P1_2   // Load DAC register control pin
#define SDI             P1_7   // Serial Data Input pin for SPI
#define SCK             P1_6   // Serial Clock pin for SPI
#define CS_BAR          P1_0   // Chip Select control pin for SPI


// __xdata keyword indicates that the variables are located in external RAM.
// uint8_t is an 8-bit unsigned integer data type.

// Variable to store the waveform type (e.g., sine, square, triangle, etc.)
__xdata uint8_t wave;

// Variable to store the gain setting for signal amplification or attenuation.
__xdata uint8_t gain;

// Variable to store the mode of operation (e.g., configuration settings).
__xdata uint8_t mode;





/*
 * Function: spi_clk_tick
 * ----------------------
 * Generates a clock tick for SPI communication by toggling the SCK line.
 * The function creates a rising edge (SCK = 1) followed by a falling edge (SCK = 0).
 */
void spi_clk_tick(void)
{
    SCK = 1;  // Set SCK line to high (1) to create a rising edge
    SCK = 0;  // Set SCK line to low (0) to create a falling edge
    return;   // Return from the function
}


/*
 * Function: dac_update_output
 * ---------------------------
 * Updates the output of a digital-to-analog converter (DAC) with different waveform data.
 * The function cycles through sine, square, triangular, and sawtooth waveforms.
 * Parameters:
 *    - None
 * Returns:
 *    - None
 */
void dac_update_output(void)
{
    __xdata static uint16_t counter = 0;  // Static counter variable for waveform position

    // Arrays representing different waveform data
    // Sine wave data
    __xdata uint8_t static sine_wave[256]={128 ,
131 ,
134 ,
137 ,
140 ,
144 ,
147 ,
150 ,
153 ,
156 ,
159 ,
162 ,
165 ,
168 ,
171 ,
174 ,
177 ,
180 ,
182 ,
185 ,
188 ,
191 ,
194 ,
196 ,
199 ,
201 ,
204 ,
206 ,
209 ,
211 ,
214 ,
216 ,
218 ,
220 ,
222 ,
224 ,
226 ,
228 ,
230 ,
232 ,
234 ,
236 ,
237 ,
239 ,
240 ,
242 ,
243 ,
244 ,
246 ,
247 ,
248 ,
249 ,
250 ,
251 ,
251 ,
252 ,
253 ,
253 ,
254 ,
254 ,
254 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
254 ,
254 ,
253 ,
253 ,
252 ,
252 ,
251 ,
250 ,
249 ,
248 ,
247 ,
246 ,
245 ,
244 ,
242 ,
241 ,
240 ,
238 ,
236 ,
235 ,
233 ,
231 ,
229 ,
227 ,
225 ,
223 ,
221 ,
219 ,
217 ,
215 ,
212 ,
210 ,
208 ,
205 ,
203 ,
200 ,
197 ,
195 ,
192 ,
189 ,
187 ,
184 ,
181 ,
178 ,
175 ,
172 ,
169 ,
167 ,
164 ,
160 ,
157 ,
154 ,
151 ,
148 ,
145 ,
142 ,
139 ,
136 ,
133 ,
130 ,
126 ,
123 ,
120 ,
117 ,
114 ,
111 ,
108 ,
105 ,
102 ,
99 ,
96 ,
92 ,
89 ,
87 ,
84 ,
81 ,
78 ,
75 ,
72 ,
69 ,
67 ,
64 ,
61 ,
59 ,
56 ,
53 ,
51 ,
48 ,
46 ,
44 ,
41 ,
39 ,
37 ,
35 ,
33 ,
31 ,
29 ,
27 ,
25 ,
23 ,
21 ,
20 ,
18 ,
16 ,
15 ,
14 ,
12 ,
11 ,
10 ,
9 ,
8 ,
7 ,
6 ,
5 ,
4 ,
4 ,
3 ,
3 ,
2 ,
2 ,
1 ,
1 ,
1 ,
1 ,
1 ,
1 ,
1 ,
2 ,
2 ,
2 ,
3 ,
3 ,
4 ,
5 ,
5 ,
6 ,
7 ,
8 ,
9 ,
10 ,
12 ,
13 ,
14 ,
16 ,
17 ,
19 ,
20 ,
22 ,
24 ,
26 ,
28 ,
30 ,
32 ,
34 ,
36 ,
38 ,
40 ,
42 ,
45 ,
47 ,
50 ,
52 ,
55 ,
57 ,
60 ,
62 ,
65 ,
68 ,
71 ,
74 ,
76 ,
79 ,
82 ,
85 ,
88 ,
91 ,
94 ,
97 ,
100 ,
103 ,
106 ,
109 ,
112 ,
116 ,
119 ,
122 ,
125 ,
128 ,
};
// Square wave data
    __xdata uint8_t static square_wave[256]={0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
0 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
255 ,
};

// Triangular wave data
    __xdata uint8_t static triangular_value_wave[256]={0 ,
2 ,
4 ,
6 ,
8 ,
10 ,
12 ,
14 ,
16 ,
18 ,
20 ,
22 ,
24 ,
26 ,
28 ,
30 ,
32 ,
34 ,
36 ,
38 ,
40 ,
42 ,
44 ,
46 ,
48 ,
50 ,
52 ,
54 ,
56 ,
58 ,
60 ,
62 ,
64 ,
66 ,
68 ,
70 ,
72 ,
74 ,
76 ,
78 ,
80 ,
82 ,
84 ,
86 ,
88 ,
90 ,
92 ,
94 ,
96 ,
98 ,
100 ,
102 ,
104 ,
106 ,
108 ,
110 ,
112 ,
114 ,
116 ,
118 ,
120 ,
122 ,
124 ,
126 ,
128 ,
130 ,
132 ,
134 ,
136 ,
138 ,
140 ,
142 ,
144 ,
146 ,
148 ,
150 ,
152 ,
154 ,
156 ,
158 ,
160 ,
162 ,
164 ,
166 ,
168 ,
170 ,
172 ,
174 ,
176 ,
178 ,
180 ,
182 ,
184 ,
186 ,
188 ,
190 ,
192 ,
194 ,
196 ,
198 ,
200 ,
202 ,
204 ,
206 ,
208 ,
210 ,
212 ,
214 ,
216 ,
218 ,
220 ,
222 ,
224 ,
226 ,
228 ,
230 ,
232 ,
234 ,
236 ,
238 ,
240 ,
242 ,
244 ,
246 ,
248 ,
250 ,
252 ,
254 ,
255 ,
254 ,
252 ,
250 ,
248 ,
246 ,
244 ,
242 ,
240 ,
238 ,
236 ,
234 ,
232 ,
230 ,
228 ,
226 ,
224 ,
222 ,
220 ,
218 ,
216 ,
214 ,
212 ,
210 ,
208 ,
206 ,
204 ,
202 ,
200 ,
198 ,
196 ,
194 ,
192 ,
190 ,
188 ,
186 ,
184 ,
182 ,
180 ,
178 ,
176 ,
174 ,
172 ,
170 ,
168 ,
166 ,
164 ,
162 ,
160 ,
158 ,
156 ,
154 ,
152 ,
150 ,
148 ,
146 ,
144 ,
142 ,
140 ,
138 ,
136 ,
134 ,
132 ,
130 ,
128 ,
126 ,
124 ,
122 ,
120 ,
118 ,
116 ,
114 ,
112 ,
110 ,
108 ,
106 ,
104 ,
102 ,
100 ,
98 ,
96 ,
94 ,
92 ,
90 ,
88 ,
86 ,
84 ,
82 ,
80 ,
78 ,
76 ,
74 ,
72 ,
70 ,
68 ,
66 ,
64 ,
62 ,
60 ,
58 ,
56 ,
54 ,
52 ,
50 ,
48 ,
46 ,
44 ,
42 ,
40 ,
38 ,
36 ,
34 ,
32 ,
30 ,
28 ,
26 ,
24 ,
22 ,
20 ,
18 ,
16 ,
14 ,
12 ,
10 ,
8 ,
6 ,
4 ,
2 ,
};

// Sawtooth wave data
    __xdata uint8_t static saw_wave[256]={0 ,
1 ,
2 ,
3 ,
4 ,
5 ,
6 ,
7 ,
8 ,
9 ,
10 ,
11 ,
12 ,
13 ,
14 ,
15 ,
16 ,
17 ,
18 ,
19 ,
20 ,
21 ,
22 ,
23 ,
24 ,
25 ,
26 ,
27 ,
28 ,
29 ,
30 ,
31 ,
32 ,
33 ,
34 ,
35 ,
36 ,
37 ,
38 ,
39 ,
40 ,
41 ,
42 ,
43 ,
44 ,
45 ,
46 ,
47 ,
48 ,
49 ,
50 ,
51 ,
52 ,
53 ,
54 ,
55 ,
56 ,
57 ,
58 ,
59 ,
60 ,
61 ,
62 ,
63 ,
64 ,
65 ,
66 ,
67 ,
68 ,
69 ,
70 ,
71 ,
72 ,
73 ,
74 ,
75 ,
76 ,
77 ,
78 ,
79 ,
80 ,
81 ,
82 ,
83 ,
84 ,
85 ,
86 ,
87 ,
88 ,
89 ,
90 ,
91 ,
92 ,
93 ,
94 ,
95 ,
96 ,
97 ,
98 ,
99 ,
100 ,
101 ,
102 ,
103 ,
104 ,
105 ,
106 ,
107 ,
108 ,
109 ,
110 ,
111 ,
112 ,
113 ,
114 ,
115 ,
116 ,
117 ,
118 ,
119 ,
120 ,
121 ,
122 ,
123 ,
124 ,
125 ,
126 ,
127 ,
128 ,
129 ,
130 ,
131 ,
132 ,
133 ,
134 ,
135 ,
136 ,
137 ,
138 ,
139 ,
140 ,
141 ,
142 ,
143 ,
144 ,
145 ,
146 ,
147 ,
148 ,
149 ,
150 ,
151 ,
152 ,
153 ,
154 ,
155 ,
156 ,
157 ,
158 ,
159 ,
160 ,
161 ,
162 ,
163 ,
164 ,
165 ,
166 ,
167 ,
168 ,
169 ,
170 ,
171 ,
172 ,
173 ,
174 ,
175 ,
176 ,
177 ,
178 ,
179 ,
180 ,
181 ,
182 ,
183 ,
184 ,
185 ,
186 ,
187 ,
188 ,
189 ,
190 ,
191 ,
192 ,
193 ,
194 ,
195 ,
196 ,
197 ,
198 ,
199 ,
200 ,
201 ,
202 ,
203 ,
204 ,
205 ,
206 ,
207 ,
208 ,
209 ,
210 ,
211 ,
212 ,
213 ,
214 ,
215 ,
216 ,
217 ,
218 ,
219 ,
220 ,
221 ,
222 ,
223 ,
224 ,
225 ,
226 ,
227 ,
228 ,
229 ,
230 ,
231 ,
232 ,
233 ,
234 ,
235 ,
236 ,
237 ,
238 ,
239 ,
240 ,
241 ,
242 ,
243 ,
244 ,
245 ,
246 ,
247 ,
248 ,
249 ,
250 ,
251 ,
252 ,
253 ,
254 ,
255 ,
};

   // Array of waveform data pointers
    __xdata uint8_t* array_ptr[4] = {sine_wave, square_wave, triangular_value_wave, saw_wave};

    __xdata uint16_t command_word_a, command_word_b;  // DAC command words
    __xdata uint8_t* data_ptr;  // Pointer to selected waveform data

    // Check if in mode 0 (normal operation)
    if (mode == 0)
    {
        data_ptr = array_ptr[wave];  // Select the waveform based on 'wave' parameter
        command_word_a = *(data_ptr + counter) << 4;  // Get data from the waveform
        command_word_b = *(data_ptr + counter) << 4;

        // Apply masks and set DAC command words
        command_word_a &= A_MASK;
        command_word_b |= B_MASK;
        command_word_a |= ACTIVE_MASK;
        command_word_b |= ACTIVE_MASK;

        // Adjust gain based on the selected gain value
        if (gain == 2)
        {
            command_word_a &= GAIN_INC_MASK;
            command_word_b &= GAIN_INC_MASK;
        }
        else
        {
            command_word_a |= GAIN_DEC_MASK;
            command_word_b |= GAIN_DEC_MASK;
        }

        // Send commands to DAC
        spi_write_word(command_word_a);
        spi_write_word(command_word_b);
    }

    // Check if the counter has reached its maximum value
    if (counter == 255)
    {
        counter = 0;  // Reset counter to start from the beginning of the waveform
    }
    else
    {
        counter++;  // Increment the counter for the next iteration
    }

    return;
}


/*
 * Function: dac_set
 * -----------------
 * Sets the output of a digital-to-analog converter (DAC) with the specified data word.
 * Parameters:
 *    - data_word: The 12-bit data word to be written to the DAC.
 * Returns:
 *    - None
 */
void dac_set(uint16_t data_word)
{
    __xdata uint16_t command_word_a, command_word_b;  // DAC command words

    // Create DAC command words by left-shifting the data_word
    command_word_a = data_word << 4;
    command_word_b = data_word << 4;

    // Apply masks to set A/B channels, active mode, and gain
    command_word_a &= A_MASK;
    command_word_b |= B_MASK;
    command_word_a |= ACTIVE_MASK;
    command_word_b |= ACTIVE_MASK;
    command_word_a &= GAIN_INC_MASK;
    command_word_b &= GAIN_INC_MASK;

    // Send commands to DAC
    spi_write_word(command_word_a);
    spi_write_word(command_word_b);

    return;
}


/*
 * Function: dac_output_ctrl_change
 * -------------------------------
 * Changes the output control mode for the digital-to-analog converter (DAC).
 * In mode 0, Timer 0 is enabled, and the DAC operates in normal operation.
 * In mode 1, Timer 0 is disabled.
 * Parameters:
 *    - None
 * Returns:
 *    - None
 */
void dac_output_ctrl_change(void)
{
    // Check the current mode
    if (mode == 0)
    {
        // Switch to mode 1 and disable Timer 0
        mode = 1;
        TR0 = 0;
    }
    else
    {
        // Switch to mode 0 and enable Timer 0
        mode = 0;
        TR0 = 1;
    }

    return;
}



/*
 * Function: dac_nxt_wave
 * -----------------------
 * Advances to the next waveform in the sequence.
 * If the current waveform index is at the maximum, it wraps around to the first waveform.
 * Parameters:
 *    - None
 * Returns:
 *    - None
 */
void dac_nxt_wave(void)
{
    // Check if the current waveform index is at the maximum
    if (wave == 3)
    {
        // Wrap around to the first waveform
        wave = 0;
    }
    else
    {
        // Increment to the next waveform
        wave++;
    }

    return;
}


/*
 * Function: dac_inc_voltage
 * --------------------------
 * Increases the voltage by setting the gain variable to 2.
 * Parameters:
 *    - None
 * Returns:
 *    - None
 */
void dac_inc_voltage(void)
{
    // Set the gain variable to 2 for increased voltage
    gain = 2;

    return;
}

/*
 * Function: dac_dec_voltage
 * --------------------------
 * Decreases the voltage by setting the gain variable to 1.
 * Parameters:
 *    - None
 * Returns:
 *    - None
 */
void dac_dec_voltage(void)
{
    // Set the gain variable to 1 for decreased voltage
    gain = 1;

    return;
}


/*
 * Function: spi_write_word
 * ------------------------
 * Writes a 16-bit word to the SPI DAC using a bit-banging approach.
 * Parameters:
 *    - data_word: The 16-bit word to be written to the SPI DAC.
 * Returns:
 *    - None
 */
void spi_write_word(__xdata uint16_t data_word)
{
    __xdata uint8_t i = 0;  // Loop counter variable

    SCK = 0;                // Set SCK line to low initially
    LDAC_BAR = 1;           // Set LDAC_BAR line to high initially
    CS_BAR = 0;             // Enable communication by setting CS_BAR low

    // Loop through each bit of the data_word
    for (i = 0; i < 16; i++)
    {
        // Check the most significant bit (MSB) of the data_word
        if (data_word & SPI_MSB_MASK)
        {
            SDI = 1;  // Set SDI line to 1 if MSB is 1
        }
        else
        {
            SDI = 0;  // Set SDI line to 0 if MSB is 0
        }

        spi_clk_tick();   // Simulate a clock cycle
        data_word = data_word << 1;  // Shift data_word to the left for the next bit
    }

    CS_BAR = 1;         // Disable communication by setting CS_BAR high
    LDAC_BAR = 0;       // Set LDAC_BAR line to low
    SCK = 0;            // Set SCK line to low

    return;
}
