#include <stdint.h>
#include <stdio.h>
#include <mcs51/8051.h>
#include <mcs51/at89c51ed2.h>
#include <stdlib.h>
#include <math.h>
#include<string.h>
#include "LCD.h"

/**
 * @brief External startup function for SDCC.
 *
 * This function initializes specific control registers for the microcontroller.
 *
 * @return 0 indicating successful startup.
 */
_sdcc_external_startup()
{
    AUXR |= 0X0C;  // Set some control register (specific to the microcontroller)
    return 0;
}

// Function: main
// Description: Main function to control the program flow
void main(void)
{
    __xdata uint8_t key_pressed = 0, exit_code = 0, data_byte = 0, x = 0, y = 0, i = 0;
    __xdata uint16_t address = 0;
    __xdata uint8_t Welcome_lcd_txt[] = "WELCOME";

    // Display a welcome message on the console
    printf_tiny("\n\rWELCOME");

    // Initialize the LCD and display the welcome message
    lcd_init();
    lcd_putstr(Welcome_lcd_txt);

    // Set timer flag to start the timer
    timer_on_off_flag = 1;
    timer_init();

    // Main program loop
    while (1)
    {
        // Display the menu on the console
        printf_tiny("\n\rMenu:");
        printf_tiny("\n\r 1. LCD Jump address");
        printf_tiny("\n\r 2. Clear LCD");
        printf_tiny("\n\r 3. LCD Jump coordinates");
        printf_tiny("\n\r 4. Put string");
        printf_tiny("\n\r 5. Start or stop time");
        printf_tiny("\n\r 6. Reset time ");
        printf_tiny("\n\r 7. LCD DDRAM Dump");
        printf_tiny("\n\r 8. LCD CGRAM Dump");
        printf_tiny("\n\r 9. Create custom character \n\r");
        printf_tiny("Entered input: ");

        // Get user input
        key_pressed = getchar();
        putchar(key_pressed);
        printf_tiny("\n\r");

        // Stop the timer if it is currently running
        if (timer_on_off_flag == 1)
        {
            TR0 = 0;
        }

        // Process user input using a switch statement
        switch (key_pressed)
        {
            case '1':
                // Jump to a specific address on the LCD
                printf_tiny("\n\r LCD Jump address");
                printf_tiny("\n\r Enter the address:\t");
                address = fetch_number(16);
                lcd_goto_add(address);
                break;

            case '2':
                // Clear the LCD
                lcd_clear();
                break;

            case '3':
                // Jump to specific coordinates on the LCD
                if (timer_on_off_flag == 1)
                {
                    TR0 = 1;
                }
                printf_tiny("\n\rLCD Jump coordinates");
                printf_tiny("\n\rEnter X coordinate(row):");
                x = fetch_number(10);
                printf_tiny("\n\rEnter Y coordinate(row):");
                y = fetch_number(10);
                lcd_goto_xy(x, y);
                break;

            case '4':
                // Display a string on the LCD
                printf("Enter the string ");
                __xdata uint8_t input_string[50];
                uint8_t i = 0;
                // Read characters until Enter is pressed (13)
                while ((input_string[i] = getchar()) != 13)
                {
                    putchar(input_string[i]);
                    i++;
                }
                input_string[i] = '\0'; // Null-terminate the string
                lcd_putstr(input_string);
                break;

            case '5':
                // Start or stop the timer
                if (timer_on_off_flag == 1)
                {
                    timer_stop();
                    timer_on_off_flag = 0;
                }
                else
                {
                    timer_start();
                    timer_on_off_flag = 1;
                }
                break;

            case '6':
                // Reset the timer
                if (timer_on_off_flag == 1)
                {
                    TR0 = 1;
                }
                timer_reset();
                break;

            case '7':
                // Dump the LCD DDRAM (Display Data RAM)
                lcd_ddram_flush();
                break;

            case '8':
                // Dump the LCD CGRAM (Character Generator RAM)
                lcd_cgram_flush();
                break;

            case '9':
                // Create custom characters for the LCD
                lcd_custom_character_creation();
                break;

            default:
                // Invalid input
                printf_tiny("\n\r Invalid input!!\n\r");
                break;
        }

        // Restart the timer if it was originally running
        if (timer_on_off_flag == 1)
        {
            TR0 = 1;
        }
    }
}

