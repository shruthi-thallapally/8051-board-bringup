#include "LCD.h"

// Function: lcd_init
// Description: Initializes the LCD by sending a series of commands.
//              This function follows the initialization sequence recommended
//              for the HD44780-compatible LCD controller.
void lcd_init(void)
{
    // Wait for the LCD to stabilize after power-up
    delay_ms(15);

    // First LCD unlock sequence
    RS_CMD;
    LCD_WRITE;
    *(LCD_CMD_WRITE_ADD) = LCD_UNLOCK;
    delay_ms(5);

    // Second LCD unlock sequence
    RS_CMD;
    LCD_WRITE;
    *(LCD_CMD_WRITE_ADD) = LCD_UNLOCK;

    // Third LCD unlock sequence
    RS_CMD;
    LCD_WRITE;
    delay_ms(1);
    *(LCD_CMD_WRITE_ADD) = LCD_UNLOCK;

    // Set function mode: 8-bit data, 2-line display, 5x8 font
    lcd_cmd_write(LCD_FXN_SET);

    // Turn off the display
    lcd_cmd_write(LCD_OFF);

    // Turn on the display, cursor, and blinking
    lcd_cmd_write(LCD_ON);

    // Set entry mode: increment cursor position, no display shift
    lcd_cmd_write(LCD_ENTRY_MODE);

    // Clear the LCD screen
    lcd_cmd_write(LCD_CLRSCR);

    // Return from the function
    return;
}
// Function: lcd_row_change
// Description: Changes the active row on the LCD display to the next row.
//              This function is useful for multi-row LCD displays.
void lcd_row_change(void)
{
    // Array to store the base addresses of each row on the LCD
    __xdata uint8_t lcd_row_base_address[] = {LCD_R0_BASE, LCD_R1_BASE, LCD_R2_BASE, LCD_R3_BASE};

    // Check if the current row index is at the last row
    if (lcd_current_row >= 3)
    {
        // Wrap around to the first row if at the last row
        lcd_current_row = 0;
    }
    else
    {
        // Move to the next row
        lcd_current_row++;
    }

    // Set the LCD cursor to the base address of the new active row
    lcd_goto_add(lcd_row_base_address[lcd_current_row]);

    // Return from the function
    return;
}
// Function: lcd_busy_wait
// Description: Waits for the LCD to become not busy before proceeding.
//              This function reads the busy flag from the LCD controller
//              and waits until the flag is cleared before returning.
void lcd_busy_wait(void)
{
    // Set RS to command mode and set the LCD to read mode
    RS_CMD;
    LCD_READ;

    // Wait while the busy flag is set (indicating the LCD is busy)
    while (*LCD_CMD_READ_ADD & LCD_WAIT_MASK);

    // Return from the function once the LCD is not busy
    return;
}

// Function: lcd_goto_add
// Description: Sets the cursor position on the LCD to the specified address.
//              This function takes an address and checks whether it falls within
//              the valid range for the LCD DDRAM. If valid, it sets the cursor
//              to the specified address, updates the current row and column,
//              and waits for the LCD to become not busy.
// Parameters:
//   - address: The target address to set the cursor position.
void lcd_goto_add(__xdata uint8_t address)
{
    // Check if the address is within the valid range for the LCD DDRAM
    if ((address >= 0x90 && address <= 0x9F) || (address >= 0xD0 && address <= 0xDF) ||
        (address >= 0xC0 && address <= 0xCF) || (address >= 0x80 && address <= 0x8F))
    {
        // Wait for the LCD to become not busy
        lcd_busy_wait();

        // Set the DDRAM address by adding the DDRAM address mask
        address |= LCD_DDRAM_ADD_MASK;

        // Send the command to set the cursor position
        lcd_cmd_write(address);

        // Update the current column based on the new address
        lcd_current_column = address % LCD_WIDTH;

        // Update the current row based on the new address range
        if (address >= 0xD0 && address <= 0xDF)
        {
            lcd_current_row = 3;
        }
        if (address >= 0x90 && address <= 0x9F)
        {
            lcd_current_row = 2;
        }
        if (address >= 0xC0 && address <= 0xCF)
        {
            lcd_current_row = 1;
        }
        if (address >= 0x80 && address <= 0x8F)
        {
            lcd_current_row = 0;
        }
    }
    else
    {
        // Display an error message for an invalid address
        printf_tiny("\n\rInvalid address");
    }

    // Return from the function
    return;
}

// Function: lcd_goto_xy
// Description: Sets the cursor position on the LCD to the specified row and column.
//              This function calculates the DDRAM address based on the specified
//              row and column, then calls the lcd_goto_add function to set the cursor.
// Parameters:
//   - row: The target row for the cursor position (0 to LCD_HEIGHT-1).
//   - column: The target column for the cursor position (0 to LCD_WIDTH-1).
void lcd_goto_xy(__xdata uint8_t row, __xdata uint8_t column)
{
    // Array to store the base addresses of each row on the LCD
    __xdata uint8_t lcd_row_base_address[] = {LCD_R0_BASE, LCD_R1_BASE, LCD_R2_BASE, LCD_R3_BASE};

    // Variable to store the calculated DDRAM address
    __xdata uint8_t address = 0;

    // Check if the specified row is within the valid range
    if (row >= LCD_HEIGHT)
    {
        printf_tiny("\n\rInvalid Row number");
        return;
    }

    // Check if the specified column is within the valid range
    if (column >= LCD_WIDTH)
    {
        printf_tiny("\n\rInvalid Column number");
        return;
    }

    // Calculate the DDRAM address based on row and column
    address = lcd_row_base_address[row] + column;

    // Set the cursor position using the calculated DDRAM address
    lcd_goto_add(address);

    // Return from the function
    return;
}
// Function: lcd_cmd_write
// Description: Writes a command byte to the LCD.
//              This function first waits for the LCD to become not busy,
//              sets the RS (Register Select) to command mode, and then writes
//              the specified command byte to the LCD command register.
// Parameters:
//   - data_byte: The command byte to be written to the LCD.
void lcd_cmd_write(__xdata uint8_t data_byte)
{
    // Wait for the LCD to become not busy
    lcd_busy_wait();

    // Set RS to command mode and set the LCD to write mode
    RS_CMD;
    LCD_WRITE;

    // Write the command byte to the LCD command register
    *(LCD_CMD_WRITE_ADD) = data_byte;

    // Return from the function
    return;
}

// Function: lcd_putchar
// Description: Writes a character to the LCD at the current cursor position.
//              This function first waits for the LCD to become not busy,
//              sets the RS (Register Select) to data mode, writes the specified
//              character to the LCD data register, increments the current column,
//              and changes the active row if the current column exceeds the LCD width.
// Parameters:
//   - data_byte: The character to be written to the LCD.
void lcd_putchar(__xdata uint8_t data_byte)
{
    // Wait for the LCD to become not busy
    lcd_busy_wait();

    // Set RS to data mode and set the LCD to write mode
    RS_DATA;
    LCD_WRITE;

    // Write the character to the LCD data register
    *(LCD_DATA_WRITE_ADD) = data_byte;

    // Increment the current column
    lcd_current_column++;

    // Change the active row if the current column exceeds the LCD width
    if (lcd_current_column >= LCD_WIDTH)
    {
        lcd_row_change();
    }

    // Return from the function
    return;
}

// Function: lcd_putstr
// Description: Writes a null-terminated string to the LCD.
//              This function iterates through each character in the provided
//              string and calls the lcd_putchar function to write each character
//              to the LCD at the current cursor position.
// Parameters:
//   - text_ptr: Pointer to the null-terminated string to be written to the LCD.
void lcd_putstr(__xdata uint8_t* text_ptr)
{
    // Iterate through each character in the string until the null terminator is reached
    while (*text_ptr != '\0')
    {
        // Write the current character to the LCD using lcd_putchar
        lcd_putchar(*text_ptr);

        // Move to the next character in the string
        text_ptr++;
    }

    // Return from the function
    return;
}
// Function: lcd_clear
// Description: Clears the LCD screen and resets the cursor position to the top-left corner.
//              This function sends the clear screen command to the LCD using lcd_cmd_write,
//              then resets the current row and column variables to 0.
void lcd_clear(void)
{
    // Send the clear screen command to the LCD
    lcd_cmd_write(LCD_CLRSCR);

    // Reset the current row and column to the top-left corner
    lcd_current_row = 0;
    lcd_current_column = 0;

    // Return from the function
    return;
}

// Function: putchar
// Description: Writes a character to the serial port (UART).
//              This function waits for the UART transmit buffer to be ready,
//              then sends the specified character to the UART transmit buffer.
//              It also clears the Transmit Interrupt (TI) flag after transmission.
// Parameters:
//   - ch: The character to be written to the UART.
// Returns:
//   - The character that was written.
int putchar(int ch)
{
    // Wait for the UART transmit buffer to be ready
    while (TI == 0)
    {
        // Wait
    }

    // Send the character to the UART transmit buffer
    SBUF = ch;

    // Clear the Transmit Interrupt (TI) flag
    TI = 0;

    // Return the character that was written
    return ch;
}

// Function: getchar
// Description: Reads a character from the serial port (UART).
//              This function waits for the UART receive buffer to contain a character,
//              then reads the character from the UART receive buffer and clears the
//              Receive Interrupt (RI) flag.
// Returns:
//   - The character read from the UART receive buffer.
int getchar(void)
{
    // Wait for the UART receive buffer to contain a character
    while (RI == 0)
    {
        // Wait
    }

    // Clear the Receive Interrupt (RI) flag
    RI = 0;

    // Return the character read from the UART receive buffer
    return SBUF;
}

// Function: delay_ms
// Description: Generates a delay in milliseconds using a nested loop.
//              This function introduces a delay by iterating through a nested loop.
// Parameters:
//   - time: The duration of the delay in milliseconds.
void delay_ms(uint32_t time)
{
    uint32_t i = 0, j = 0;

    // Outer loop controls the number of iterations for the specified duration
    for (j = 0; j < time; j++)
    {
        // Inner loop introduces a delay of approximately 1 millisecond
        for (i = 0; i < 1120; i++); // Adjust the loop count for accurate timing
    }

    // Return from the function
    return;
}


// Function: fetch_number
// Description: Reads a number from the serial port (UART) and converts it to an integer.
//              This function reads characters from the UART until the Enter key (ASCII 13)
//              is pressed, forming a string of digits. It then converts the string to an
//              integer based on the specified base (e.g., decimal, hexadecimal).
// Parameters:
//   - base: The base for number conversion (e.g., 10 for decimal, 16 for hexadecimal).
// Returns:
//   - The integer value obtained from the entered digits.
uint16_t fetch_number(uint8_t base)
{
    __xdata uint8_t scanned_digit = 0, digit_array[20], digit_counter = 0, i = 0;
    __xdata uint16_t number = 0;

    // Loop until Enter key is pressed
    while (scanned_digit != 13)
    {
        scanned_digit = getchar();

        // Check if the scanned character is a valid digit or letter based on the specified base
        if (((scanned_digit >= '0') && (scanned_digit <= '9')) ||
            ((scanned_digit >= 'a') && (scanned_digit <= 'f')) ||
            ((scanned_digit >= 'A') && (scanned_digit <= 'F')))
        {
            // Print the scanned character to the console
            putchar(scanned_digit);

            // Convert the scanned character to an integer and store it in the array
            digit_array[digit_counter] = char_to_int(scanned_digit);
            digit_counter++;
        }
        else if (scanned_digit == 8) // Check for backspace
        {
            // Handle backspace by erasing the last entered character
            putchar(8);  // Print backspace
            putchar(32); // Print space
            putchar(8);  // Print backspace
            digit_counter--;
        }
    }

    // Convert the array of digits to an integer based on the specified base
    for (i = 0; i < digit_counter; i++)
    {
        number *= base;
        number += digit_array[i];
    }

    // Return the final integer value obtained from the entered digits
    return number;
}

// Function: char_to_int
// Description: Converts a character representing a digit or hexadecimal letter to its integer equivalent.
//              This function takes a character as input and returns its integer value based on the
//              digit or hexadecimal letter it represents.
// Parameters:
//   - temp: The character to be converted to an integer.
// Returns:
//   - The integer value corresponding to the input character.
uint8_t char_to_int(uint8_t temp)
{
    // Check if the character represents a digit
    if ((temp >= '0') && (temp <= '9'))
    {
        temp -= '0'; // Convert character to integer for digits
    }
    // Check if the character represents a lowercase hexadecimal letter
    else if ((temp >= 'a') && (temp <= 'f'))
    {
        temp -= 'a';
        temp += 10; // Convert character to integer for lowercase hexadecimal letters
    }
    // Check if the character represents an uppercase hexadecimal letter
    else if ((temp >= 'A') && (temp <= 'F'))
    {
        temp -= 'A';
        temp += 10; // Convert character to integer for uppercase hexadecimal letters
    }

    // Return the integer value corresponding to the input character
    return temp;
}

// Function: rtc_interrupt_handler
// Description: Interrupt service routine (ISR) for the RTC (Real-Time Clock) timer.
//              This ISR is triggered at regular intervals by the RTC timer.
//              It resets the timer values, increments the 'time' variable, and
//              calls the 'timer_display' function to update the display.
void rtc_interrupt_handler(void) __interrupt 1
{
    // Static variable to toggle between two states for time increment
    __xdata static uint16_t counter_flag = 0;

    // Clear the Timer 0 overflow flag
    TF0 = 0;

    // Reset the Timer 0 low and high values for a continuous timer
    TL0 = TIMER0_LOW;
    TH0 = TIMER0_HIGH;

    // Check the counter_flag to determine whether to increment the 'time' variable
    if (counter_flag == 0)
    {
        // Set the counter_flag to 1 to indicate the next state
        counter_flag = 1;
    }
    else
    {
        // Increment the 'time' variable and update the display
        time++;
        timer_display();

        // Reset the counter_flag for the next cycle
        counter_flag = 0;
    }
}

// Function: timer_init
// Description: Initializes the timer for real-time clock (RTC) functionality.
//              This function sets up the necessary configurations for Timer 0,
//              enabling it to act as a timer for tracking elapsed time. It also
//              initializes the 'time' variable and enables the timer interrupt.
void timer_init(void)
{
    // Initialize the 'time' variable to 0
    time = 0;

    // Enable Timer 0 overflow interrupt and global interrupts (EA)
    IE |= 0x82;

    // Configure Timer 0 in Mode 1 (16-bit mode)
    TMOD |= 0x01;
    TMOD &= 0xF1;

    // Set initial values for Timer 0 low and high registers
    TL0 = TIMER0_LOW;
    TH0 = TIMER0_HIGH;

    // Start Timer 0
    TR0 = 1;

    // Return from the function
    return;
}

// Function: timer_display
// Description: Updates the LCD display with the elapsed time from the 'time' variable.
//              This function calculates the elapsed time in minutes, seconds, and
//              tenths of a second, then updates the LCD display with the formatted time.
void timer_display(void)
{
    // Variables to store tenths of a second, seconds, and minutes
    __xdata uint8_t tenth_of_second = 0, seconds = 0, minutes = 0;

    // Variables to temporarily store LCD row and column positions
    __xdata uint8_t temp_lcd_row = 0, temp_lcd_column = 0;

    // Save the current LCD row and column positions
    temp_lcd_column = lcd_current_column;
    temp_lcd_row = lcd_current_row;

    // Calculate tenths of a second, seconds, and minutes from 'time' variable
    tenth_of_second = time % 10;
    seconds = (time / 10) % 60;
    minutes = time / 600;

    // Move the cursor to the specified position and print the formatted time
    lcd_goto_xy(3, 8);
    lcd_print_number(minutes, 2);
    lcd_putchar(':');
    lcd_print_number(seconds, 2);
    lcd_putchar('.');
    lcd_print_number(tenth_of_second, 1);

    // Restore the original LCD row and column positions
    lcd_goto_xy(temp_lcd_row, temp_lcd_column);

    // Return from the function
    return;
}

// Function: timer_stop
// Description: Stops the real-time clock (RTC) timer by disabling Timer 0.
//              This function turns off Timer 0 to halt the incrementing of time.
void timer_stop(void)
{
    // Disable Timer 0 to stop the real-time clock (RTC) timer
    TR0 = 0;
}

// Function: timer_start
// Description: Starts the real-time clock (RTC) timer by enabling Timer 0.
//              This function turns on Timer 0 to resume the incrementing of time.
void timer_start(void)
{
    // Enable Timer 0 to start the real-time clock (RTC) timer
    TR0 = 1;
}

// Function: timer_reset
// Description: Resets the elapsed time to zero by setting the 'time' variable to 0.
//              This function initializes the 'time' variable, effectively resetting
//              the elapsed time tracked by the real-time clock (RTC) timer.
void timer_reset(void)
{
    // Set the 'time' variable to 0 to reset the elapsed time
    time = 0;
}

// Function: lcd_print_number
// Description: Prints a signed integer to the LCD display with specified display width.
//              This function converts a signed integer to its ASCII representation
//              and prints it on the LCD display. The display width parameter
//              determines the minimum width of the printed number, and leading
//              zeros are added if necessary.
// Parameters:
//   - number: The signed integer to be printed on the LCD display.
//   - display_width: The minimum width of the printed number on the LCD display.
void lcd_print_number(__xdata int32_t number, __xdata uint8_t display_width)
{
    // Array to store ASCII characters of the printed number
    __xdata uint8_t temp_ascii_store[10];

    // Temporary variables for loop control and value comparison
    __xdata int8_t counter = 0;
    __xdata uint32_t value_check = 0;

    // Loop to determine the number of digits required based on the display width
    for (counter = display_width; counter > 1; counter--)
    {
        // Check the display width and the value to determine if leading zero is needed
        lcd_busy_wait();
        switch (counter)
        {
        case 2:
            value_check = 9;
            if (number <= value_check)
            {
                RS_DATA;
                LCD_WRITE;
                *(LCD_DATA_WRITE_ADD) = '0';
            }
            break;

        case 3:
            value_check = 99;
            if (number <= value_check)
            {
                RS_DATA;
                LCD_WRITE;
                *(LCD_DATA_WRITE_ADD) = '0';
            }
            break;

        case 4:
            value_check = 999;
            if (number <= value_check)
            {
                RS_DATA;
                LCD_WRITE;
                *(LCD_DATA_WRITE_ADD) = '0';
            }
            break;
        }
    }

    // Loop to convert the integer to ASCII and store in the temporary array
    do
    {
        temp_ascii_store[counter] = '0' + number % 10;
        number /= 10;
        counter++;
    } while (number > 0);

    // Loop to print the ASCII characters to the LCD display
    for (counter -= 1; counter > 0; counter--)
    {
        lcd_busy_wait();
        RS_DATA;
        LCD_WRITE;
        *(LCD_DATA_WRITE_ADD) = temp_ascii_store[counter];
    }

    // Return from the function
    return;
}

// Function: lcd_ddram_flush
// Description: Displays a hexadecimal dump of the LCD DDRAM (Display Data RAM) on the console.
//              This function reads the contents of the LCD DDRAM in hexadecimal format
//              and prints a formatted hexdump on the console. Each row in the hexdump
//              corresponds to 16 bytes of DDRAM data.
void lcd_ddram_flush(void)
{
    // Variables for loop control, temporary storage, and DDRAM address
    __xdata uint8_t count = 0, i = 0, temp_storage = 0, data_byte = 0;
    __xdata uint16_t address = 0x80;

    // Set the temporary storage with the LCD DDRAM address mask
    temp_storage = lcd_ddram_address_mask;

    // Set LCD in command mode and write the LCD DDRAM address to access data
    RS_CMD;
    LCD_WRITE;
    lcd_cmd_write(temp_storage);

    // Print a header for the hexdump on the console
    printf_tiny("\n\rDDRAM Hexdump");

    // Loop through each row in the hexdump
    for (count = 0; count < 5; count++)
    {
        putchar('\n');
        putchar('\r');

        // Print the current address in hexadecimal format
        print_number_hex(address, 2);
        putchar(':');

        // Loop through each byte in the current row and print its hexadecimal value
        for (i = 0; i < 16; i++)
        {
            putchar(32); // space

            // Set LCD in data mode, read the data from DDRAM, and print its hexadecimal value
            RS_DATA;
            LCD_READ;
            data_byte = *(LCD_DATA_READ_ADD);
            print_number_hex(data_byte, 2);
        }

        // Move to the next row in DDRAM
        address += 16;
    }

    // Restore the LCD cursor to its original position
    lcd_goto_xy(lcd_current_row, lcd_current_column);

    // Return from the function
    return;
}


// Function: lcd_cgram_flush
// Description: Displays a hexadecimal dump of the LCD CGRAM (Character Generator RAM) on the console.
//              This function reads the contents of the LCD CGRAM in hexadecimal format
//              and prints a formatted hexdump on the console. Each row in the hexdump
//              corresponds to 16 bytes of CGRAM data.
void lcd_cgram_flush(void)
{
    // Variables for loop control, temporary storage, and CGRAM address
    __xdata uint8_t count = 0, i = 0, temp_storage = 0, data_byte = 0;
    __xdata uint16_t address = 0;

    // Set the temporary storage with the LCD CGRAM address mask
    temp_storage = lcd_cgram_address_mask;
    temp_storage &= lcd_cgram_address_mask_2;

    // Set LCD in command mode and write the LCD CGRAM address to access data
    RS_CMD;
    LCD_WRITE;
    lcd_cmd_write(temp_storage);

    // Print a header for the hexdump on the console
    printf_tiny("\n\rCGRAM Hexdump");

    // Loop through each row in the hexdump
    for (count = 0; count < 4; count++)
    {
        putchar('\n');
        putchar('\r');

        // Print the current address in hexadecimal format
        print_number_hex(address, 2);
        putchar(':');

        // Loop through each byte in the current row and print its hexadecimal value
        for (i = 0; i < 16; i++)
        {
            putchar(32); // space

            // Set LCD in data mode, read the data from CGRAM, and print its hexadecimal value
            RS_DATA;
            LCD_READ;
            data_byte = *(LCD_DATA_READ_ADD);
            print_number_hex(data_byte, 2);
        }

        // Move to the next row in CGRAM
        address += 16;
    }

    // Restore the LCD cursor to its original position
    lcd_goto_xy(lcd_current_row, lcd_current_column);

    // Return from the function
    return;
}
// Function: print_number_hex
// Description: Prints a 32-bit unsigned integer in hexadecimal format to the console.
//              This function converts a 32-bit unsigned integer to its hexadecimal
//              representation and prints it on the console. The display width parameter
//              determines the minimum width of the printed hexadecimal number, and leading
//              zeros are added if necessary.
// Parameters:
//   - number: The 32-bit unsigned integer to be printed in hexadecimal format.
//   - display_width: The minimum width of the printed hexadecimal number.
void print_number_hex(__xdata uint32_t number, __xdata uint8_t display_width)
{
    // Array to store ASCII characters of the printed hexadecimal number
    __xdata uint8_t temp_ascii_store[10];

    // Temporary variables for loop control and value comparison
    __xdata int8_t counter = 0;
    __xdata uint32_t value_check = 0;

    // Loop to determine the number of digits required based on the display width
    for (counter = display_width; counter > 1; counter--)
    {
        // Check the display width and the value to determine if leading zero is needed
        switch (counter)
        {
        case 4:
            value_check = 0xFFF;
            if (number <= value_check)
            {
                putchar('0');
            }
            break;

        case 3:
            value_check = 0xFF;
            if (number <= value_check)
            {
                putchar('0');
            }
            break;

        case 2:
            value_check = 0xF;
            if (number <= value_check)
            {
                putchar('0');
            }
            break;
        }
    }

    // Loop to convert the integer to hexadecimal and store in the temporary array
    do
    {
        temp_ascii_store[counter] = int_to_char(number % 16);
        number /= 16;
        counter++;
    } while (number > 0);

    // Loop to print the ASCII characters to the console
    for (counter -= 1; counter >= 0; counter--)
    {
        putchar(temp_ascii_store[counter]);
    }

    // Return from the function
    return;
}


// Function: int_to_char
// Description: Converts an integer to its corresponding hexadecimal character.
//              This function takes an integer value and returns its hexadecimal
//              character representation. It includes a switch statement to handle
//              values between 0 and 15.
// Parameters:
//   - temp: The integer value to be converted to a hexadecimal character.
// Returns:
//   - The corresponding hexadecimal character.
int8_t int_to_char(int temp)
{
    switch (temp)
    {
    case 0:
        return '0';

    case 1:
        return '1';

    case 2:
        return '2';

    case 3:
        return '3';

    case 4:
        return '4';

    case 5:
        return '5';

    case 6:
        return '6';

    case 7:
        return '7';

    case 8:
        return '8';

    case 9:
        return '9';

    case 10:
        return 'A';

    case 11:
        return 'B';

    case 12:
        return 'C';

    case 13:
        return 'D';

    case 14:
        return 'E';

    case 15:
        return 'F';

    default:
        // Handle cases where temp is not in the range [0, 15]
        return '0';
    }
}

// Function: lcdcreatechar
// Description: Creates a custom character for the LCD and stores it in CGRAM.
//              This function allows the creation of custom characters for the LCD
//              display. It takes a character code (ccode) and an array of row values
//              representing the pixel pattern for each row of the custom character.
// Parameters:
//   - ccode: The character code for the custom character (must be between 0 and 7).
//   - row_vals: An array containing the pixel pattern for each row of the custom character.
void lcdcreatechar(unsigned char ccode, unsigned char row_vals[]) {
    // Variables for custom character address, temporary character storage, and current LCD position
    __xdata uint8_t custom_character_address = 0, temp_char = 0;
    __xdata uint8_t current_r = 0, current_c = 0;

    // Save the current LCD position
    current_r = lcd_current_row;
    current_c = lcd_current_column;

    // Check if the character code is valid (between 0 and 7)
    if (ccode >= 8) {
        printf_tiny("\n\rInvalid character code. It must be between 0 and 7.");
        return;
    }

    // Set the CGRAM address for the custom character
    lcd_cmd_write(0x40 + (ccode * 8));

    // Write the pixel pattern for each row to CGRAM
    for (uint8_t i = 0; i < 8; i++) {
        // Calculate the CGRAM address for the current row of the custom character
        custom_character_address = lcd_cgram_address_mask | (ccode << 3) | i;
        custom_character_address &= lcd_cgram_address_mask_2;

        // Set the LCD to write mode and write the CGRAM address
        lcd_cmd_write(custom_character_address);

        // Combine the pixel pattern for the row with the character code and write to LCD
        temp_char = row_vals[i];
        temp_char |= (ccode << 5);
        lcd_putchar(temp_char);
    }

    // Inform the user that the custom character has been created
    printf_tiny("\n\rCustom character created with code %d.", ccode);

    // Restore the LCD cursor to its original position
    lcd_goto_xy(current_r, current_c);

    // Display the custom character on the LCD
    lcd_putchar(ccode);
}




// Function: enter_custom_character
// Description: Allows the user to enter a custom pixel pattern for a specific character.
//              This function prompts the user to enter the pixel pattern (in hexadecimal)
//              for a custom character with the specified character code (ccode). It uses
//              the lcdcreatechar function to create and display the custom character on the LCD.
// Parameters:
//   - ccode: The character code for the custom character (must be between 0 and 7).
void enter_custom_character(__xdata uint8_t ccode) {
    // Prompt the user to enter the pixel pattern for the custom character
    printf_tiny("\n\rEnter pixel pattern for character %d (in hex): ", ccode);

    // Array to store the pixel pattern for each row of the custom character
    unsigned char row_vals[8];

    // Loop to get user input for each row
    for (uint8_t i = 0; i < 8; ++i) {
        // Prompt the user for the pixel pattern for the current row
        printf_tiny("\n\rRow %d: ", i);

        // Use fetch_number to get a hex value for the pixel pattern
        row_vals[i] = fetch_number(16); // Assuming user enters hex values for pixel pattern
    }

    // Call the lcdcreatechar function to create and display the custom character
    lcdcreatechar(ccode, row_vals);
}


// Function: lcd_custom_character_creation
// Description: Initiates the process of creating a custom character for the LCD.
//              This function guides the user through the process of creating a custom
//              character by prompting for a character code and then calling the
//              enter_custom_character function to enter the pixel pattern.
void lcd_custom_character_creation(void) {
    // Print a header indicating the start of the custom character creation process
    printf_tiny("\n\rCreate Custom Character");

    // Prompt the user to enter a character code for the custom character (0-7)
    printf_tiny("\n\rEnter character code (0-7): ");

    // Get user input for the character code using fetch_number
    uint8_t ccode = fetch_number(10);

    // Check if the entered character code is valid (between 0 and 7)
    if (ccode >= 0 && ccode <= 7) {
        // Call the enter_custom_character function to complete the custom character creation
        enter_custom_character(ccode);
    } else {
        // Inform the user about an invalid character code
        printf_tiny("\n\rInvalid character code. It must be between 0 and 7.");
    }
}


