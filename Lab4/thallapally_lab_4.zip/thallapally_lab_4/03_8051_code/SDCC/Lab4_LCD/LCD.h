#ifndef LCD_H_INCLUDED
#define LCD_H_INCLUDED
#include <stdint.h>
#include <stdio.h>
#include <mcs51/8051.h>
#include <mcs51/at89c51ed2.h>
#include <stdlib.h>

// LCD control macros
#define RS_CMD P1_6 = 0
#define RS_DATA P1_6 = 1
#define LCD_WRITE P1_7 = 0
#define LCD_READ P1_7 = 1

// LCD row base addresses
#define LCD_R0_BASE (0x80)
#define LCD_R1_BASE (0xC0)
#define LCD_R2_BASE (0x90)
#define LCD_R3_BASE (0xD0)

// LCD memory addresses
#define LCD_CMD_READ_ADD ((__xdata uint8_t*)0x8002)
#define LCD_CMD_WRITE_ADD ((__xdata uint8_t*)0x8004)
#define LCD_DATA_READ_ADD ((__xdata uint8_t*)0x8000)
#define LCD_DATA_WRITE_ADD ((__xdata uint8_t*)0x8000)

// LCD constants
#define LCD_WIDTH (16)
#define LCD_HEIGHT (4)
#define LCD_CLRSCR (0x01)
#define LCD_CURSOR_HOME (0x02)
#define LCD_WAIT_MASK (0x80)
#define LCD_DDRAM_ADD_MASK (0x80)
#define LCD_ENTRY_MODE (0x06)
#define LCD_DISPLAY_CURSOR (0x0F)
#define LCD_DISPLAY_SHIFT (0x14)
#define LCD_FXN_SET (0x38)
#define LCD_UNLOCK (0x30)
#define LCD_OFF (0x08)
#define LCD_ON  (0x0F)
#define LCD_CURSOR_OFF  (0x0C)
#define TIMER0_LOW (0xEF)
#define TIMER0_HIGH (0x73)

#define lcd_ddram_address_mask (0x80)
#define lcd_cgram_address_mask (0x40)
#define lcd_cgram_address_mask_2 (0x7F)

// Function prototypes
// Function: lcd_print_number
// Description: Print an integer on the LCD display with specified width
void lcd_print_number(__xdata int32_t number, __xdata uint8_t display_width);

// Function: timer_init
// Description: Initialize the timer
void timer_init(void);

// Function: timer_display
// Description: Display the timer value on the LCD
void timer_display(void);

// Function: timer_stop
// Description: Stop the timer
void timer_stop(void);

// Function: timer_start
// Description: Start the timer
void timer_start(void);

// Function: timer_reset
// Description: Reset the timer
void timer_reset(void);

// Function: lcd_row_change
// Description: Change the active row on the LCD
void lcd_row_change(void);

// Function: lcd_init
// Description: Initialize the LCD
void lcd_init(void);

// Function: lcd_busy_wait
// Description: Wait for the LCD to become not busy
void lcd_busy_wait(void);

// Function: lcd_goto_add
// Description: Set the LCD cursor to the specified address
void lcd_goto_add(__xdata uint8_t address);

// Function: lcd_goto_xy
// Description: Set the LCD cursor to the specified row and column
void lcd_goto_xy(__xdata uint8_t row, __xdata uint8_t column);

// Function: lcd_putchar
// Description: Display a character on the LCD
void lcd_putchar(__xdata uint8_t data_byte);

// Function: lcd_putstr
// Description: Display a string on the LCD
void lcd_putstr(__xdata uint8_t* text_ptr);

// Function: lcd_cmd_write
// Description: Write a command to the LCD
void lcd_cmd_write(__xdata uint8_t data_byte);

// Function: putchar
// Description: Write a character to the standard output (stdout)
int putchar(int ch);

// Function: getchar
// Description: Read a character from the standard input (stdin)
int getchar(void);

// Function: delay_ms
// Description: Delay execution for the specified time in milliseconds
void delay_ms(uint32_t time);

// Function: fetch_number
// Description: Fetch a number from the standard input with the specified base
uint16_t fetch_number(uint8_t base);

// Function: char_to_int
// Description: Convert a character to an integer
uint8_t char_to_int(uint8_t temp);

// Function: lcd_clear
// Description: Clear the LCD display
void lcd_clear(void);

// Function: lcd_ddram_flush
// Description: Flush the DDRAM (Display Data RAM) of the LCD
void lcd_ddram_flush(void);

// Function: lcd_cgram_flush
// Description: Flush the CGRAM (Character Generator RAM) of the LCD
void lcd_cgram_flush(void);

// Function: print_number_hex
// Description: Print a hexadecimal number on the LCD with specified width
void print_number_hex(__xdata uint32_t number, __xdata uint8_t display_width);

// Function: int_to_char
// Description: Convert an integer to a character
int8_t int_to_char(int temp);

// Function: lcdcreatechar
// Description: Create a custom character for the LCD
void lcdcreatechar(unsigned char ccode, unsigned char row_vals[]);

// Function: lcd_custom_character_creation
// Description: Create custom characters for the LCD
void lcd_custom_character_creation(void);

// Function: enter_custom_character
// Description: Display a custom character on the LCD
void enter_custom_character(__xdata uint8_t ccode);


// Global variables
__xdata uint8_t lcd_current_column,lcd_current_row,timer_on_off_flag;
__xdata uint32_t time;

#endif // LCD_H_INCLUDED
