#ifndef HEAP_SIZE
#define HEAP_SIZE 5000
#endif

__xdata char __sdcc_heap[HEAP_SIZE];
const unsigned int __sdcc_heap_size = HEAP_SIZE;
